tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -4
echo "=== LOCAL ==="
curl -sS -m 8 -o /dev/null -w "local: HTTP %{http_code} (%{time_total}s)\n" http://127.0.0.1:9999/ 2>&1
echo "=== PROC ==="
pgrep -af rideconnect_arm64 | head -1
echo "=== BACKLOG ==="
ss -tlnp 2>/dev/null | grep 9999 | head -1
exit
