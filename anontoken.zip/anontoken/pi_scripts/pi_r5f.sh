date '+%H:%M:%S'
echo "=== apache 60s count ==="
tail -100000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | wc -l
echo "=== UA top 8 (60s) ==="
tail -100000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | awk -F'"' '{print $6}' | sed 's/(.*//; s/ .*//' | sort | uniq -c | sort -rn | head -8
echo "=== IP thật (CF-Connecting-IP) top 5 ==="
tail -100000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | awk '{print $1}' | sort | uniq -c | sort -rn | head -5
echo "=== CF RSS ==="
ps -o rss= -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null
echo "=== load ==="
uptime
exit
