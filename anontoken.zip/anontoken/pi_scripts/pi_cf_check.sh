echo "=== ps: cloudflare ==="
ps aux | grep -iE 'cloudflared|cloudflare|tunnel' | grep -v grep
echo "=== systemd ==="
systemctl list-units --type=service --all 2>/dev/null | grep -iE 'cloudflare|cloudflared|tunnel'
echo "=== which cloudflared ==="
command -v cloudflared || echo "cloudflared NOT installed"
echo "=== listening ports ==="
ss -tlnp 2>/dev/null | head -20
exit
