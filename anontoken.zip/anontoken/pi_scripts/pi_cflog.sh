echo "=== cloudflared pane tail 12 ==="
tmux capture-pane -t 0:0.0 -p -S - 2>&1 | tail -12
exit
