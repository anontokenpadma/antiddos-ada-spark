echo "=== md5 + size ==="
md5sum /home/anontoken/anontoken/rideconnect_arm64.new 2>&1
wc -c /home/anontoken/anontoken/rideconnect_arm64.new 2>&1
exit
