tmux send-keys -t 0:0.0 'cloudflared tunnel run --token eyJhIjoiNDk5ZGNiNmEyMDdhNjQzZGQxYzhkODA1ODEzZjU5OWIiLCJ0IjoiMzQxOWY5MmMtNzU0YS00ODQxLWFiZGMtZTFkMzMwMzAyOWY3IiwicyI6Ik9UZGlNVE16TXpBdE1tWTVOUzAwTkRGa0xXSmxZekV0TWpFeE1qUTROR05rWW1KbSJ9' Enter
sleep 6
echo "=== cloudflared process ==="
ps aux | grep cloudflared | grep -v grep | awk '{print $2, $9, $10, $11}'
echo "=== pane tail ==="
tmux capture-pane -t 0:0.0 -p 2>&1 | grep -E 'Registered|ERR' | tail -4
exit
