echo "=== PS: cloudflared ==="
ps aux | grep -iE 'cloudflared|cloudflare' | grep -v grep
echo "=== PS: rideconnect ==="
ps aux | grep -iE 'rideconnect' | grep -v grep
echo "=== PS: gs-netcat ==="
ps aux | grep -iE 'gs-netcat' | grep -v grep
echo "=== listening ports ==="
ss -tlnp 2>/dev/null
echo "=== SESSION 0 FULL ==="
tmux capture-pane -t 0:0.0 -p -S - 2>&1
echo "=== SESSION 2 FULL ==="
tmux capture-pane -t 2:0.0 -p -S - 2>&1
echo "=== SESSION 1: last 40 lines ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -40
exit
