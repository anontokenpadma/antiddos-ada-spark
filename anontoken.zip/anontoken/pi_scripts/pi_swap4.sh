cd /home/anontoken/anontoken
mv -f rideconnect_arm64 rideconnect_arm64.static_broken
mv -f rideconnect_arm64.new rideconnect_arm64
chmod +x rideconnect_arm64
tmux send-keys -t 1:0.0 C-c
sleep 2
tmux send-keys -t 1:0.0 "./rideconnect_arm64 9999 127.0.0.1 80" Enter
sleep 3
echo "=== pane tail ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -4
echo "=== proc ==="
ps -o pid,etime,rss,args -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null | cut -c1-70
echo "=== local test ==="
curl -sS -m 5 -o /dev/null -w "local HTTP %{http_code}\n" http://127.0.0.1:9999/
exit
