echo "=== OLD .rela.dyn types ==="
readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.dyn/,/rela.plt/' | grep -oE "R_AARCH64_[A-Z0-9_]+" | sort | uniq -c | sort -rn | head -8
echo "=== BAD .rela.dyn types ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.dyn/,/rela.plt/' | grep -oE "R_AARCH64_[A-Z0-9_]+" | sort | uniq -c | sort -rn | head -8
echo "=== OLD dynsym UND full ==="
readelf -s rideconnect_arm64 2>/dev/null | grep " UND " | awk '{print $8}' | sort | head -40
exit
