echo "=== ps cloudflared ==="
ps aux | grep -i cloudflared | grep -v grep | awk '{print $2, $9, $10, $11, $12, $13}'
echo "=== pane 0 tail ==="
tmux capture-pane -t 0:0.0 -p -S - 2>&1 | tail -8
exit
