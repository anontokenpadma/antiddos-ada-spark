sleep 1
echo "=== proxy pane (tail 6) ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -6
echo "=== proc ==="
ps -o pid,etime,rss,args -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null | cut -c1-80
echo "=== local test ==="
curl -sS -m 5 -o /dev/null -w "local: HTTP %{http_code}\n" http://127.0.0.1:9999/
echo "=== tunnel test ==="
curl -sS -m 15 -o /dev/null -w "tunnel: HTTP %{http_code}\n" https://anontokenforever.dpdns.org/
exit
