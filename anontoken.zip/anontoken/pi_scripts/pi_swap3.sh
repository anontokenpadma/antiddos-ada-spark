cd /home/anontoken/anontoken
mv -f rideconnect_arm64 rideconnect_arm64.old2
mv -f rideconnect_arm64.new rideconnect_arm64
chmod +x rideconnect_arm64
# stop old proxy (graceful) via tmux session 1
tmux send-keys -t 1:0.0 C-c
sleep 2
tmux send-keys -t 1:0.0 "./rideconnect_arm64 9999 127.0.0.1 80" Enter
sleep 2
echo "=== proxy pane ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -5
echo "=== proc ==="
ps -o pid,etime,rss,args -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null | cut -c1-70
exit
