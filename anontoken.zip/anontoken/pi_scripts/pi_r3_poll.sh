date '+%Y-%m-%d %H:%M:%S %z'
echo "=== load/mem ==="
uptime
free -m | head -2
echo "=== rideconnect ==="
ps -o pid,etime,%cpu,%mem,rss,args -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null
echo "=== tasks/threads ==="
ls /proc/$(pgrep -f rideconnect_arm64 | head -1)/task 2>/dev/null | wc -l
echo "=== fds ==="
ls /proc/$(pgrep -f rideconnect_arm64 | head -1)/fd 2>/dev/null | wc -l
echo "=== conns :9999 ==="
ss -tan 2>/dev/null | grep ':9999' | awk '{print $1}' | sort | uniq -c
echo "=== total conns ==="
ss -tan 2>/dev/null | wc -l
echo "=== proxy log (tail 8) ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -8
echo "=== apache tail 6 ==="
tail -6 /var/log/apache2/access.log 2>/dev/null
echo "=== cloudflared rss ==="
ps -o pid,%cpu,rss,etime,args -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | cut -c1-80
