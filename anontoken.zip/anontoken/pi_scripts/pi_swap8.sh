cd /home/anontoken/anontoken
mv -f rideconnect_arm64 rideconnect_arm64.r6c
mv -f rideconnect_arm64.new rideconnect_arm64
chmod +x rideconnect_arm64
tmux send-keys -t 1:0.0 C-c
sleep 2
tmux send-keys -t 1:0.0 "./rideconnect_arm64 9999 127.0.0.1 80" Enter
sleep 3
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -3
sleep 1
curl -sS -m 8 -o /dev/null -w "local: HTTP %{http_code} (%{time_total}s)\n" http://127.0.0.1:9999/ 2>&1
exit
