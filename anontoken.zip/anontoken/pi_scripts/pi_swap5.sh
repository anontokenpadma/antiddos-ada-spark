cd /home/anontoken/anontoken
mv -f rideconnect_arm64 rideconnect_arm64.r4
mv -f rideconnect_arm64.new rideconnect_arm64
chmod +x rideconnect_arm64
tmux send-keys -t 1:0.0 C-c
sleep 2
tmux send-keys -t 1:0.0 "./rideconnect_arm64 9999 127.0.0.1 80" Enter
sleep 3
echo "=== pane ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -3
echo "=== connlimit rule ==="
iptables -L INPUT -n | grep 9999
echo "=== persist check ==="
which netfilter-persistent 2>/dev/null || echo "no netfilter-persistent"
ls /etc/iptables/rules.v4 2>/dev/null || echo "no rules.v4"
exit
