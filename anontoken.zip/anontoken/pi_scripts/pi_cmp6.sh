echo "=== OLD .rela.plt (tail) ==="
readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.plt/,0' | tail -4
echo "=== BAD .rela.plt (tail) ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.plt/,0' | tail -4
echo "=== OLD .rela.dyn count ==="
readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.dyn/,/rela.plt/' | grep -cE "R_AARCH64" 
echo "=== BAD .rela.dyn count ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.dyn/,/rela.plt/' | grep -cE "R_AARCH64"
echo "=== OLD GOT size ==="
readelf -S rideconnect_arm64 2>/dev/null | grep -E "\.got"
echo "=== BAD GOT size ==="
readelf -S rideconnect_arm64.bad 2>/dev/null | grep -E "\.got"
exit
