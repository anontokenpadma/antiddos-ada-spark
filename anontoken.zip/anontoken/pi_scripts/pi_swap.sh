cd /home/anontoken/anontoken
chmod +x rideconnect_arm64.new
mv rideconnect_arm64 rideconnect_arm64.old
mv rideconnect_arm64.new rideconnect_arm64
echo "=== stopped old proxy ==="
tmux send-keys -t 1:0.0 C-c
sleep 2
ps aux | grep rideconnect | grep -v grep || echo "old proxy gone"
echo "=== start new proxy ==="
tmux send-keys -t 1:0.0 './rideconnect_arm64 9999 127.0.0.1 80' Enter
sleep 2
echo "=== process ==="
ps aux | grep rideconnect | grep -v grep
echo "=== listening ==="
ss -tlnp 2>/dev/null | grep 9999
echo "=== pane ==="
tmux capture-pane -t 1:0.0 -p 2>&1 | tail -8
exit
