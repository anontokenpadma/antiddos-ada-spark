rm -f rideconnect_arm64.bad rideconnect_arm64.r6b
ls -la rideconnect_arm64*
echo "=== MD5 LIVE ==="
md5sum rideconnect_arm64
exit
