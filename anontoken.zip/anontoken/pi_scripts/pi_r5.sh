date '+%H:%M:%S'
echo "CF_RSS_KB:"
ps -o rss= -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null
echo "PROXY_RSS_KB:"
ps -o rss= -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null
echo "MEM:"
awk '/Mem:/{print $2"/"$3}' <(free -m)
echo "LOAD:"
uptime
echo "CONNS9999:"
ss -tan 2>/dev/null | grep ':9999' | awk '{print $1}' | sort | uniq -c
echo "LOG:"
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -3
exit
