echo "=== current state ==="
date '+%H:%M:%S'
uptime
free -m | head -2 | tail -1
echo "=== cf rss ==="
ps -o rss -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | tail -1
echo "=== attack still on? (conns :9999) ==="
ss -tan 2>/dev/null | grep -c ':9999'
echo "=== apply connlimit ==="
iptables -C INPUT -p tcp --dport 9999 -m connlimit --connlimit-above 400 --connlimit-mask 0 -j REJECT --reject-with tcp-reset 2>/dev/null && echo "rule already exists" || iptables -I INPUT 1 -p tcp --dport 9999 -m connlimit --connlimit-above 400 --connlimit-mask 0 -j REJECT --reject-with tcp-reset
echo "=== verify rule ==="
iptables -L INPUT -n --line-numbers | head -6
exit
