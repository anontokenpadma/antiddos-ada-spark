which netfilter-persistent iptables-save 2>/dev/null | head -2
mkdir -p /etc/iptables
iptables-save > /etc/iptables/rules.v4 2>/dev/null && echo "SAVED rules.v4"
grep -c '9999' /etc/iptables/rules.v4 2>/dev/null
ls -la /etc/iptables/ 2>/dev/null | tail -3
exit
