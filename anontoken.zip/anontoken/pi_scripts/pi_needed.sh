readelf -d /home/anontoken/anontoken/rideconnect_arm64.old2 2>/dev/null | grep -E 'NEEDED|RPATH|RUNPATH|interpreter'
exit
