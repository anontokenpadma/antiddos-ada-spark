sleep 1
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -3
ss -lnt | grep 9999
curl -sS -m 5 -o /dev/null -w "local:%{http_code}\n" http://127.0.0.1:9999/
exit
