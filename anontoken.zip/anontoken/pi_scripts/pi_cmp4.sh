echo "=== OLD PLT names ==="
readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.plt/,0' | grep -E "JUMP_SL" | awk '{print $6}' | sort > /tmp/old_names.txt
wc -l /tmp/old_names.txt
echo "=== BAD PLT names ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.plt/,0' | grep -E "JUMP_SL" | awk '{print $6}' | sort > /tmp/bad_names.txt
wc -l /tmp/bad_names.txt
echo "=== NEW symbols (in bad not old) ==="
comm -13 /tmp/old_names.txt /tmp/bad_names.txt
echo "=== symbols present in old only ==="
comm -23 /tmp/old_names.txt /tmp/bad_names.txt
exit
