file /home/anontoken/anontoken/rideconnect_arm64.old2
file /home/anontoken/anontoken/rideconnect_arm64 2>/dev/null
ls -la /home/anontoken/anontoken/rideconnect_arm64*
exit
