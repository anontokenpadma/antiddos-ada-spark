date '+%H:%M:%S'
echo "=== cf rss ==="
ps -o rss,etime -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | tail -1
echo "=== mem ==="
free -m | head -2 | tail -1
echo "=== conns :9999 ==="
ss -tan 2>/dev/null | grep ':9999' | awk '{print $1}' | sort | uniq -c
echo "=== load ==="
uptime
exit
