date '+%H:%M:%S'
echo "=== cloudflared ==="
ps -o pid,%cpu,rss,etime,args -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | cut -c1-70
echo "=== proxy ==="
ps -o pid,%cpu,rss,etime,args -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null | cut -c1-70
echo "=== apache last 5s requests ==="
tail -200 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-5)) print}' | wc -l
echo "=== apache status last 60s ==="
tail -2000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | awk '{print $9}' | sort | uniq -c
exit
