echo "=== proxy pane ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -vE '^$' | tail -4
echo "=== cloudflared tail ==="
tmux capture-pane -t 0:0.0 -p -S - 2>&1 | grep -E 'ERR|INF' | tail -4
echo "=== ss 9999 ==="
ss -tlnp 2>/dev/null | grep 9999
exit
