echo "=== proxy proc ==="
ps -o pid,etime,rss,args -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null | cut -c1-75
echo "=== backlog ==="
ss -lnt | grep 9999
echo "=== connlimit ==="
iptables -L INPUT -n | grep -c 'dpt:9999'
echo "=== md5 ==="
md5sum /home/anontoken/anontoken/rideconnect_arm64
echo "=== load/mem ==="
uptime
free -m | awk '/Mem:/{print "mem_used=" $3}'
echo "=== cf rss ==="
ps -o rss= -p $(pgrep -f 'cloudflared tunnel' | head -1)
exit
