cat /home/anontoken/anontoken/rideconnect_arm64 | /home/anontoken/anontoken/gs-netcat_linux-aarch64 -s transferold123 -q > /dev/null 2>&1
echo "pi_sender_done"
exit
