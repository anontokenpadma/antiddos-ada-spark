date '+%H:%M:%S'
echo "=== cf rss ==="
ps -o rss,etime -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | tail -1
echo "=== mem ==="
free -m | head -2 | tail -1
echo "=== check-host requests 60s ==="
tail -4000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | grep -c CheckHost
echo "=== apache 200 count 60s ==="
tail -4000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | awk '{print $9}' | sort | uniq -c | tail -5
echo "=== listen backlog ==="
ss -lnt 2>/dev/null | grep 9999
echo "=== somaxconn/backlog ==="
cat /proc/sys/net/core/somaxconn
exit
