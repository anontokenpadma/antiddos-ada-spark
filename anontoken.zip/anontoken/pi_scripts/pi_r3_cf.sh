date '+%H:%M:%S'
echo "=== mem ==="
free -m | head -2
echo "=== cf rss ==="
ps -o pid,%cpu,rss,etime -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null
echo "=== proxy ==="
ps -o pid,%cpu,rss,etime -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null
echo "=== proxy log tail 3 ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -3
echo "=== conns ==="
ss -tan 2>/dev/null | grep ':9999' | awk '{print $1}' | sort | uniq -c
echo "=== apache 200 count last 30s ==="
awk -v d="$(date '+%d/%b/%Y:%H:%M' -d '30 seconds ago')" '$0>=d' /var/log/apache2/access.log 2>/dev/null | grep -c ' 200 '
echo "=== oom dmesg ==="
dmesg 2>/dev/null | grep -i 'killed process' | tail -2
