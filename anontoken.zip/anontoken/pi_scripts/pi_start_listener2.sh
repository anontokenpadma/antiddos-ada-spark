rm -f /home/anontoken/anontoken/rideconnect_arm64.new
nohup /home/anontoken/anontoken/gs-netcat_linux-aarch64 -l -s transferfix123 -q > /home/anontoken/anontoken/rideconnect_arm64.new 2>/dev/null &
echo "listener started: $!"
exit
