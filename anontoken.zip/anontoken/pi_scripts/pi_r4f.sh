date '+%H:%M:%S'
echo "CF_RSS=$(ps -o rss= -p $(pgrep -f 'cloudflared tunnel' | head -1))"
echo "PROXY_RSS=$(ps -o rss= -p $(pgrep -f rideconnect_arm64 | head -1))"
free -m | awk '/Mem:/{print "MEM_USED_MB=" $3}'
uptime
echo "CONNS=$(ss -tan | grep -c ':9999')"
exit
