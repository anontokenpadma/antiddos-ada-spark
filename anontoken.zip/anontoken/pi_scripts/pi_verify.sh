echo "=== md5 + size rideconnect_arm64.new ==="
md5sum /home/anontoken/anontoken/rideconnect_arm64.new 2>&1
wc -c /home/anontoken/anontoken/rideconnect_arm64.new 2>&1
ls -la /home/anontoken/anontoken/rideconnect_arm64.new 2>&1
exit
