sleep 1
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -3
echo "PROC:"
ps -o pid,rss,etime -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null | tail -1
echo "LOCAL:"
curl -sS -m 5 -o /dev/null -w "%{http_code}\n" http://127.0.0.1:9999/
exit
