echo "=== OLD (working) .rela.plt ==="
readelf -r rideconnect_arm64 2>/dev/null | grep -A3 "rela.plt" | head -8
echo "=== OLD reloc count by type ==="
readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.plt/,0' | grep -oE "R_AARCH64_[A-Z0-9_]+" | sort | uniq -c
echo "=== BAD .rela.plt ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | grep -A3 "rela.plt" | head -8
echo "=== BAD reloc count by type ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.plt/,0' | grep -oE "R_AARCH64_[A-Z0-9_]+" | sort | uniq -c
echo "=== OLD sections ==="
readelf -S rideconnect_arm64 2>/dev/null | grep -E "rela|PLT|GOT" | head -10
echo "=== BAD sections ==="
readelf -S rideconnect_arm64.bad 2>/dev/null | grep -E "rela|PLT|GOT" | head -10
exit
