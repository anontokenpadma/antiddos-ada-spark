echo "=== local test qua proxy (127.0.0.1:9999) ==="
curl -sS -m 5 -o /dev/null -w "local: HTTP %{http_code}\n" http://127.0.0.1:9999/ 2>&1
echo "=== cloudflared process ==="
ps aux | grep cloudflared | grep -v grep | awk '{print $2, $9, $11, $12, $13}'
echo "=== cloudflared recent logs ==="
tmux capture-pane -t 0:0.0 -p -S - 2>&1 | tail -6
exit
