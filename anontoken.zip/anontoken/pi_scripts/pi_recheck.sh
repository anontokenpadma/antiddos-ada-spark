echo "=== tmux ls ==="
tmux ls 2>&1
echo "=== ps: rideconnect ==="
ps aux | grep -iE 'rideconnect|cloudflared' | grep -v grep
echo "=== listening ports ==="
ss -tlnp 2>/dev/null | grep -E '9999|:80|:443' 
echo "=== SESSION rideconnect: last 25 lines ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -25
echo "=== SESSION cloudflared: last 10 lines ==="
tmux capture-pane -t 0:0.0 -p -S - 2>&1 | tail -10
exit
