echo "=== tmux ls ==="
tmux ls 2>&1
echo "=== tmux sessions detail ==="
tmux list-sessions -F '#{session_name}: #{session_windows} windows [#{session_width}x#{session_height}] #{session_activity_string}' 2>&1
echo "=== windows/panes per session ==="
tmux list-windows -a -F '#{session_name}:#{window_index}.#{pane_index} [#{pane_width}x#{pane_height}] #{window_name}' 2>&1
exit
