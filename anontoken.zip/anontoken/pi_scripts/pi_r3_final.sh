date '+%H:%M:%S'
echo "=== apache requests 14:01:30-14:03:00 (window tấn công) ==="
awk '$0 >= "[19/Aug/2026:14:01:30" && $0 <= "[19/Aug/2026:14:03:00"' /var/log/apache2/access.log | wc -l
echo "=== apache status codes trong window ==="
awk '$0 >= "[19/Aug/2026:14:01:30" && $0 <= "[19/Aug/2026:14:03:00"' /var/log/apache2/access.log | awk '{print $9}' | sort | uniq -c
echo "=== UA phân bố window ==="
awk '$0 >= "[19/Aug/2026:14:01:30" && $0 <= "[19/Aug/2026:14:03:00"' /var/log/apache2/access.log | awk -F'"' '{print $6}' | sed 's/(.*//' | sort | uniq -c | sort -rn | head -8
echo "=== reject count (toàn bộ scrollback) ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -c 'reject connection'
echo "=== accept error count ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -c 'accept error'
echo "=== oom check ==="
dmesg 2>/dev/null | grep -i 'out of memory' | tail -2
echo "=== cloudflared rss hiện tại ==="
ps -o pid,rss,etime -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null
