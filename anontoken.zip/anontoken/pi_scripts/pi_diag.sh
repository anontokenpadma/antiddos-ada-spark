echo "=== TIMESTAMP ==="; date '+%H:%M:%S'
PID=$(pgrep -f rideconnect_arm64 | head -1)
echo "PID=$PID"
echo "=== ulimit -n (FD limit) ==="
ulimit -n
echo "=== FD count ==="
ls /proc/$PID/fd 2>/dev/null | wc -l
echo "=== task (thread) count ==="
ls /proc/$PID/task 2>/dev/null | wc -l
echo "=== proc status ==="
grep -E 'VmRSS|Threads|VmSize' /proc/$PID/status 2>/dev/null
echo "=== listen queue ==="
ss -tlnp 2>/dev/null | grep 9999
echo "=== proxy log tail ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -vE 'reject connection' | tail -8
exit
