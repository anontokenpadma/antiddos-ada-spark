echo "=== OLD .comment ==="
readelf -p .comment rideconnect_arm64 2>/dev/null | tail -5
echo "=== BAD .comment ==="
readelf -p .comment rideconnect_arm64.bad 2>/dev/null | tail -5
echo "=== OLD dynamic tags ==="
readelf -d rideconnect_arm64 2>/dev/null | grep -E "FLAGS|BIND_NOW|RELRO" 
echo "=== BAD dynamic tags ==="
readelf -d rideconnect_arm64.bad 2>/dev/null | grep -E "FLAGS|BIND_NOW|RELRO"
echo "=== OLD section count ==="
readelf -S rideconnect_arm64 2>/dev/null | grep -c "\["
echo "=== BAD section count ==="
readelf -S rideconnect_arm64.bad 2>/dev/null | grep -c "\["
exit
