readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.plt/,0' | awk '{print $NF}' | sort > /tmp/old_syms.txt
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.plt/,0' | awk '{print $NF}' | sort > /tmp/bad_syms.txt
echo "=== OLD unique count: $(sort -u /tmp/old_syms.txt | wc -l)  BAD: $(sort -u /tmp/bad_syms.txt | wc -l)"
echo "=== in bad, not in old ==="
comm -13 /tmp/old_syms.txt /tmp/bad_syms.txt
echo "=== in old, not in bad ==="
comm -23 /tmp/old_syms.txt /tmp/bad_syms.txt
exit
