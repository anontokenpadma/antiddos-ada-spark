ps -o rss= -p $(pgrep -f 'cloudflared tunnel' | head -1)
ps -o rss= -p $(pgrep -f rideconnect_arm64 | head -1)
awk '/Mem:/{print $3}' <(free -m)
ss -tan | grep -c ':9999'
exit
