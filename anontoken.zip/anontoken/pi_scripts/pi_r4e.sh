date '+%H:%M:%S'
ps -o rss -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | tail -1
free -m | head -2 | tail -1
exit
