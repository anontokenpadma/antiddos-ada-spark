echo "=== FULL pane 1 ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -30
echo "=== pgrep ==="
pgrep -af rideconnect
exit
