tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -4
echo "=== LOCAL ==="
curl -sS -m 8 -o /dev/null -w "local: HTTP %{http_code} (%{time_total}s)\n" http://127.0.0.1:9999/ 2>&1
echo "=== OLD (running) NEEDED ==="
readelf -d rideconnect_arm64 2>/dev/null | grep -E "NEEDED|FLAGS_1" 
echo "=== BAD NEEDED ==="
readelf -d rideconnect_arm64.bad 2>/dev/null | grep -E "NEEDED|FLAGS_1"
echo "=== BAD RELRO/PLT ==="
readelf -d rideconnect_arm64.bad 2>/dev/null | grep -E "BIND_NOW|FLAGS"
exit
