echo "=== dmesg OOM ==="
dmesg 2>/dev/null | grep -iE 'oom|out of memory|killed process' | tail -6
echo "=== cloudflared binary? ==="
command -v cloudflared || ls -la /home/anontoken/anontoken/cloudflared 2>/dev/null || echo "not found in PATH/home"
exit
