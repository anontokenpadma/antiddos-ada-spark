echo "=== TIMESTAMP ==="
date '+%Y-%m-%d %H:%M:%S %z'
echo "=== rideconnect RSS trend ==="
ps -o pid,etime,%cpu,%mem,rss -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null
echo "=== total reject lines in scrollback ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -c 'reject connection'
echo "=== first reject timestamp ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep 'reject connection' | head -1
echo "=== last reject timestamp ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep 'reject connection' | tail -1
echo "=== apache requests during attack (12:44-12:45) ==="
grep -c '19/Aug/2026:12:4[45]' /var/log/apache2/access.log 2>/dev/null
echo "=== dmesg OOM check ==="
dmesg 2>/dev/null | grep -iE 'oom|out of memory|killed process' | tail -5
echo "=== load now ==="
uptime
exit
