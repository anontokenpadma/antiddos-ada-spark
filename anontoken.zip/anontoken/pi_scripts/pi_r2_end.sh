echo "=== now ==="; date '+%H:%M:%S'
uptime
echo "=== proxy proc ==="
PID=$(pgrep -f rideconnect_arm64 | head -1); ps -o pid,etime,%cpu,%mem,rss -p $PID 2>/dev/null
echo "=== proxy log (last non-reject) ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -vE 'reject connection|^$' | tail -6
echo "=== apache requests 12:57-12:58 ==="
grep -c '19/Aug/2026:12:5[78]' /var/log/apache2/access.log 2>/dev/null
echo "=== last apache line ==="
tail -2 /var/log/apache2/access.log 2>/dev/null
exit
