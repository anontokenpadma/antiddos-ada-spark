cd /home/anontoken/anontoken
echo "=== verify ==="
md5sum rideconnect_arm64.new
wc -c rideconnect_arm64.new
echo "=== swap ==="
chmod +x rideconnect_arm64.new
mv rideconnect_arm64 rideconnect_arm64.r2
mv rideconnect_arm64.new rideconnect_arm64
echo "=== restart proxy ==="
tmux send-keys -t 1:0.0 C-c
sleep 2
tmux send-keys -t 1:0.0 './rideconnect_arm64 9999 127.0.0.1 80' Enter
sleep 2
ps aux | grep rideconnect | grep -v grep
echo "=== pane ==="
tmux capture-pane -t 1:0.0 -p 2>&1 | grep -E 'listening|shutdown' | tail -3
exit
