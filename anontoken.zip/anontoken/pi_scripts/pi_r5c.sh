date '+%H:%M:%S'
echo "CF:"
ps -o rss= -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null
echo "LOAD:"
uptime
echo "CONNS:"
ss -tan 2>/dev/null | grep ':9999' | awk '{print $1}' | sort | uniq -c | head -8
echo "APACHE_60S:"
tail -3000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | wc -l
echo "APACHE_STATS_60S:"
tail -3000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | awk '{print $9}' | sort | uniq -c
echo "REJECTS:"
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -c 'reject'
exit
