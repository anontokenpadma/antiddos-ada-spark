ls -la rideconnect_arm64 rideconnect_arm64.bad rideconnect_arm64.r6b 2>/dev/null
echo "=== md5 ==="
md5sum rideconnect_arm64 rideconnect_arm64.bad rideconnect_arm64.r6b 2>/dev/null
exit
