readelf -r rideconnect_arm64.bad 2>/dev/null | grep -B1 -A1 "R_AARCH64_NONE"
echo "=== symtab of that index ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | grep "R_AARCH64_NONE" | awk '{print $2}' | head -1
exit
