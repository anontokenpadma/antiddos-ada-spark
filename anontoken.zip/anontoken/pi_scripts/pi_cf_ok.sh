ps -o pid,rss,etime -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | tail -1
exit
