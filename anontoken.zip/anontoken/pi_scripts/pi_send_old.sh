rm -f /home/anontoken/anontoken/old_bin.new
nohup /home/anontoken/anontoken/gs-netcat_linux-aarch64 -l -s transferold123 -q > /home/anontoken/anontoken/old_bin.new 2>/dev/null &
echo "listener: $!"
exit
