rm -f /home/anontoken/anontoken/old_bin.new
nohup sh -c 'cat /home/anontoken/anontoken/rideconnect_arm64 | /home/anontoken/anontoken/gs-netcat_linux-aarch64 -s transferold123 -q > /dev/null' 2>/dev/null &
echo "sender: $!"
exit
