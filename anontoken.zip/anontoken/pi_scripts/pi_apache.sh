echo "=== apache access log (tail 15) ==="
tail -15 /var/log/apache2/access.log 2>&1
echo "=== apache error log (tail 5) ==="
tail -5 /var/log/apache2/error.log 2>&1
exit
