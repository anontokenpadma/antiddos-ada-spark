tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -6
exit
