date '+%H:%M:%S'
echo "=== load/mem ==="
uptime
free -m | head -2
echo "=== proxy ==="
ps -o pid,%cpu,rss,etime -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null | tail -1
echo "=== cloudflared ==="
ps -o pid,%cpu,rss,etime -p $(pgrep -f 'cloudflared tunnel' | head -1) 2>/dev/null | tail -1
echo "=== conns :9999 ==="
ss -tan 2>/dev/null | grep ':9999' | awk '{print $1}' | sort | uniq -c
echo "=== total conns ==="
ss -tan 2>/dev/null | wc -l
echo "=== proxy log tail 5 ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -5
exit
