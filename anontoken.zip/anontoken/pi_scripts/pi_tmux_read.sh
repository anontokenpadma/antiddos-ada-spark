echo "===== SESSION 0 (cloudflared) ====="
tmux capture-pane -t 0 -p -S - 2>&1
echo "===== SESSION 1 (rideconnect_arm64) ====="
tmux capture-pane -t 1 -p -S - 2>&1
echo "===== SESSION 2 (bash) ====="
tmux capture-pane -t 2 -p -S - 2>&1
exit
