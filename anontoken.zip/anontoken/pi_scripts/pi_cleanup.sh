pkill -f 'gs-netcat.*transfertoken123' 2>/dev/null
sleep 1
pgrep -af 'gs-netcat' | grep -v grep | head -3
echo "CLEANED"
exit
