echo "=== OLD dynsym RtlGenRandom ==="
readelf -s rideconnect_arm64 2>/dev/null | grep -iE "RtlGenRandom|SystemFunction036"
echo "=== BAD dynsym RtlGenRandom ==="
readelf -s rideconnect_arm64.bad 2>/dev/null | grep -iE "RtlGenRandom|SystemFunction036"
echo "=== OLD .rela.plt count ==="
readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.plt/,0' | grep -c "R_AARCH64"
echo "=== BAD .rela.plt count ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.plt/,0' | grep -c "R_AARCH64"
echo "=== OLD UND symbols ==="
readelf -s rideconnect_arm64 2>/dev/null | grep " UND " | awk '{print $8}' | sort | uniq -c | sort -rn | head -5
echo "=== BAD UND symbols ==="
readelf -s rideconnect_arm64.bad 2>/dev/null | grep " UND " | awk '{print $8}' | sort | uniq -c | sort -rn | head -5
exit
