cd /home/anontoken/anontoken
ls -la rideconnect_arm64* 2>/dev/null | awk '{print $NF, $5}'
echo "=== restore .r4 ==="
mv -f rideconnect_arm64.r4 rideconnect_arm64
chmod +x rideconnect_arm64
tmux send-keys -t 1:0.0 "./rideconnect_arm64 9999 127.0.0.1 80" Enter
sleep 3
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -3
exit
