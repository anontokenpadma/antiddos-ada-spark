date '+%H:%M:%S'
echo "=== apache window 14:01:30-14:03:00 ==="
grep -a '19/Aug/2026:14:0[123]' /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= "19/Aug/2026:14:01:30" && t <= "19/Aug/2026:14:03:00") print}' | wc -l
echo "=== status codes ==="
grep -a '19/Aug/2026:14:0[123]' /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= "19/Aug/2026:14:01:30" && t <= "19/Aug/2026:14:03:00") print}' | awk '{print $9}' | sort | uniq -c
echo "=== UA top ==="
grep -a '19/Aug/2026:14:0[123]' /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= "19/Aug/2026:14:01:30" && t <= "19/Aug/2026:14:03:00") print}' | awk -F'"' '{print $6}' | sed 's/(.*//; s/ .*//' | sort | uniq -c | sort -rn | head -6
echo "=== reject trong scrollback ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -c 'reject connection'
echo "=== load hiện tại ==="
uptime
