iptables -L INPUT -n | grep -c 9999
exit
