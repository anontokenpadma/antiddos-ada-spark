echo "=== OLD symbols ==="
readelf -r rideconnect_arm64 2>/dev/null | awk '/rela.plt/,0' | grep -oE "@[A-Za-z0-9_.]+" | sort > /tmp/old_syms.txt
cat /tmp/old_syms.txt | head -50
echo "=== BAD symbols ==="
readelf -r rideconnect_arm64.bad 2>/dev/null | awk '/rela.plt/,0' | grep -oE "@[A-Za-z0-9_.]+" | sort > /tmp/bad_syms.txt
cat /tmp/bad_syms.txt | head -50
echo "=== DIFF (in bad, not in old) ==="
comm -13 /tmp/old_syms.txt /tmp/bad_syms.txt
exit
