date '+%H:%M:%S'
echo "APACHE_60S:"
tail -200000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | wc -l
echo "UA_60S:"
tail -200000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | awk -F'"' '{print $6}' | sed 's/(.*//; s/ .*//' | sort | uniq -c | sort -rn | head -4
echo "CHECKHOST_60S:"
tail -200000 /var/log/apache2/access.log | awk -F'[][]' '{t=$2; if (t >= strftime("%d/%b/%Y:%H:%M:%S", systime()-60)) print}' | grep -c CheckHost
echo "REJECTS_ROUND6:"
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | grep -a '15:5[4-9]' | grep -c 'reject'
echo "CF:"
ps -o rss= -p $(pgrep -f 'cloudflared tunnel' | head -1)
exit
