md5sum /home/anontoken/anontoken/rideconnect_arm64
exit
