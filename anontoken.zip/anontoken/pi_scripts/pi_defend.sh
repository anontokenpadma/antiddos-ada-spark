echo "=== TIMESTAMP ==="
date '+%Y-%m-%d %H:%M:%S %z'
echo "=== load / mem ==="
uptime
free -m | head -2
echo "=== rideconnect proc ==="
ps -o pid,etime,%cpu,%mem,rss,args -p $(pgrep -f rideconnect_arm64 | head -1) 2>/dev/null
echo "=== conns to :9999 ==="
ss -tan 2>/dev/null | grep ':9999' | awk '{print $1}' | sort | uniq -c
echo "=== total conns ==="
ss -tan 2>/dev/null | wc -l
echo "=== rideconnect log (tail 12) ==="
tmux capture-pane -t 1:0.0 -p -S - 2>&1 | tail -12
echo "=== cloudflared log (tail 5) ==="
tmux capture-pane -t 0:0.0 -p -S - 2>&1 | tail -5
echo "=== apache access (tail 5) ==="
tail -5 /var/log/apache2/access.log 2>&1
exit
