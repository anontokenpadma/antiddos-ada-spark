echo "=== internet ==="
curl -s -m 8 -o /dev/null -w "github: %{http_code}\n" https://github.com 2>&1 || echo "no direct internet"
echo "=== tools ==="
for t in python3 curl wget openssl gcc gnatmake nc; do command -v $t >/dev/null 2>&1 && echo "$t: YES ($(command -v $t))" || echo "$t: NO"; done
python3 --version 2>&1
echo "=== project dir ==="
ls -la /home/anontoken/anontoken/ | head -20
echo "=== net tools ==="
command -v ss netstat lsof 2>/dev/null
exit
