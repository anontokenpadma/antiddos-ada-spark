#!/usr/bin/env bash
# Cross-compile the rideconnect proxy for Linux AArch64 (Raspberry Pi).
#
# Usage:  bash build_arm64.sh
# Output: bin/rideconnect_arm64
#
# Notes:
#  - Toolchain: /home/jovyan/.local/aarch64 (GCC 16 + binutils 2.47.50).
#  - The Debian libc.so/libm.so in the toolchain are linker scripts with
#    hardcoded /usr/aarch64-linux-gnu/... paths (the toolchain was moved),
#    so we feed the linker fixed copies from /tmp/mylib.
#  - --defsym=SystemFunction036=0: the source carries a Linker_Options pragma
#    (--unresolved-symbols=ignore-all) for the Windows-only RtlGenRandom
#    import. With ignore-all the linker leaves an empty R_AARCH64_NONE PLT
#    slot that old glibc loaders on the Pi reject with "unexpected PLT reloc
#    type 0x00". Resolving the symbol to 0 removes the hole.

set -e

TC=/home/jovyan/.local/aarch64
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

export PATH="$TC/usr/bin:$PATH"
export LD_LIBRARY_PATH="$TC/usr/lib/x86_64-linux-gnu"

# Fixed libc/libm linker scripts (hardcoded toolchain paths are correct here)
mkdir -p /tmp/mylib
if [ ! -f /tmp/mylib/libc.so ]; then
  cat > /tmp/mylib/libc.so <<'EOF'
OUTPUT_FORMAT(elf64-littleaarch64)
GROUP ( /home/jovyan/.local/aarch64/usr/aarch64-linux-gnu/lib/libc.so.6 /home/jovyan/.local/aarch64/usr/aarch64-linux-gnu/lib/libc_nonshared.a  AS_NEEDED ( /home/jovyan/.local/aarch64/usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 ) )
EOF
fi
if [ ! -f /tmp/mylib/libm.so ]; then
  cat > /tmp/mylib/libm.so <<'EOF'
OUTPUT_FORMAT(elf64-littleaarch64)
GROUP ( /home/jovyan/.local/aarch64/usr/aarch64-linux-gnu/lib/libm.so.6 AS_NEEDED ( /home/jovyan/.local/aarch64/usr/aarch64-linux-gnu/lib/libmvec.so.1 ) )
EOF
fi

ROOT=$(cd "$(dirname "$0")" && pwd)
cd "$WORK"
cp "$ROOT/src/rideconnect.adb" .
cp "$ROOT/src/graceful_shutdown.ads" .
cp "$ROOT/src/graceful_shutdown.adb" .

aarch64-linux-gnu-gnatmake -O2 -gnatVa -gnat2022 \
  -o rideconnect_arm64 rideconnect.adb \
  -largs -L/tmp/mylib -Wl,--defsym=SystemFunction036=0

# Sanity: no R_AARCH64_NONE PLT hole (breaks old glibc loaders)
NONE=$(aarch64-linux-gnu-readelf -r rideconnect_arm64 2>/dev/null \
  | awk '/rela.plt/,0' | grep -c R_AARCH64_NONE || true)
if [ "$NONE" != "0" ]; then
  echo "ERROR: binary contains $NONE R_AARCH64_NONE PLT relocs" >&2
  exit 1
fi

cp rideconnect_arm64 "$ROOT/bin/rideconnect_arm64"
echo "OK: bin/rideconnect_arm64 ($(stat -c%s "$ROOT/bin/rideconnect_arm64") bytes)"
