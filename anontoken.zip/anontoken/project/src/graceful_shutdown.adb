package body Graceful_Shutdown is

   protected body Signal_Handler is

      procedure Handle is
      begin
         Flag := True;
      end Handle;

   end Signal_Handler;

   function Requested return Boolean is
   begin
      return Flag;
   end Requested;

   procedure Install is
      use Ada.Interrupts;
   begin
      Attach_Handler
        (Signal_Handler.Handle'Access, Ada.Interrupts.Names.SIGINT);
      Attach_Handler
        (Signal_Handler.Handle'Access, Ada.Interrupts.Names.SIGTERM);
   end Install;

end Graceful_Shutdown;
