#!/usr/bin/env python3
"""Regenerate the SPARK proof harness (spark_core.ads / spark_core.adb)
from the real source rideconnect.adb, so the verified code is exactly
the deployed code.

Boundaries are located by content markers (robust to small edits).
"""
import re
import sys

SRC = "rideconnect.adb"


def find(pattern, start=1):
    with open(SRC) as f:
        for i, line in enumerate(f, 1):
            if i >= start and re.search(pattern, line):
                return i
    raise SystemExit("marker not found: " + pattern)


def lines(a, b):
    with open(SRC) as f:
        all_lines = f.read().split("\n")
    return all_lines[a - 1 : b]


def emit_ads():
    use_t   = find(r"use type Ada\.Streams\.Stream_Element;")
    max_hs  = find(r"Max_Head_Size")
    hp_spec = find(r"package Http_Parser is")
    hp_end  = find(r"end Http_Parser;")
    rl_spec = find(r"package Rate_Limiter is")
    rl_end  = find(r"end Rate_Limiter;")
    er_spec = find(r"package Errors is")
    er_end  = find(r"end Errors;")
    io_spec = find(r"package IO is")
    io_end  = find(r"end IO;")
    cl_spec = find(r"package Cli is")
    cl_end  = find(r"end Cli;")

    out = []
    out.append("with Ada.Streams;")
    out.append("")
    out.append("package Spark_Core is")
    out.append("   pragma SPARK_Mode (On);")
    out.append("")
    out += lines(use_t, use_t + 6)          # 3 use-type + blank + 3 subtype
    out.append("")
    out += lines(max_hs, hp_spec - 2)       # config constants .. end record
    out.append("")
    out += lines(hp_spec, hp_end)           # Http_Parser spec
    out.append("")
    out += lines(rl_spec, rl_end)           # Rate_Limiter spec
    out.append("")
    out += lines(er_spec, er_end)           # Errors spec
    out.append("")
    out += lines(cl_spec, cl_end)           # Cli spec
    out.append("")
    # IO spec: the real package is platform code (SPARK_Mode Off) whose
    # body is stubbed below; keep only Get_Env (the one the SPARK core
    # calls) so spec and stub body stay consistent.
    io_lines = lines(io_spec, io_end)
    keep = [io_lines[0]]  # 'package IO is'
    for ln in io_lines[1:]:
        if re.search(r"Get_Env", ln):
            keep.append(ln)
    keep.append("   end IO;")
    out += keep
    out.append("")
    out.append("end Spark_Core;")
    return "\n".join(out) + "\n"


def emit_adb():
    hp_body = find(r"package body Http_Parser is")
    hp_end  = find(r"end Http_Parser;", hp_body)
    rl_body = find(r"package body Rate_Limiter is")
    rl_end  = find(r"end Rate_Limiter;", rl_body)
    er_body = find(r"package body Errors is")
    er_end  = find(r"end Errors;", er_body)
    cl_body = find(r"package body Cli is")
    cl_end  = find(r"end Cli;", cl_body)

    out = []
    out.append("package body Spark_Core is")
    out.append("   pragma SPARK_Mode (On);")
    out.append("")
    out += lines(hp_body, hp_end)           # Http_Parser body
    out.append("")
    out += lines(rl_body, rl_end)           # Rate_Limiter body
    out.append("")
    out += lines(er_body, er_end)           # Errors body
    out.append("")
    out += lines(cl_body, cl_end)           # Cli body
    out.append("")
    # IO body stub: the real IO is platform code (SPARK_Mode Off); only
    # Get_Env is needed by the SPARK core.
    out.append("   package body IO is")
    out.append("      function Get_Env (Name : String) return String is")
    out.append("      begin")
    out.append("         pragma Unreferenced (Name);")
    out.append('         return "";')
    out.append("      end Get_Env;")
    out.append("   end IO;")
    out.append("")
    out.append("end Spark_Core;")
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "both"
    if mode in ("ads", "both"):
        open("spark_core.ads", "w").write(emit_ads())
        print("wrote spark_core.ads")
    if mode in ("adb", "both"):
        open("spark_core.adb", "w").write(emit_adb())
        print("wrote spark_core.adb")
