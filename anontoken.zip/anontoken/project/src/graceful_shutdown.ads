--  graceful_shutdown.ads
--  =====================================================================
--  Library-level signal handling for rideconnect.
--
--  Exposes a volatile flag that is set when SIGINT or SIGTERM is
--  received, so the accept loop can stop accepting, close the listener
--  and drain in-flight connections before exiting.
--
--  NOTE: this handler must live in a library-level package (not nested
--  inside the main procedure) because Ada requires interrupt handlers to
--  be library-level entities.
--  =====================================================================

with Ada.Interrupts;
with Ada.Interrupts.Names;

package Graceful_Shutdown is

   function Requested return Boolean;
   --  True once a shutdown signal (SIGINT or SIGTERM) has been received.

   procedure Install;
   --  Attach SIGINT and SIGTERM handlers. Call once before serving.

private

   --  GNAT reserves SIGINT for its runtime (Ctrl-C abort); tell it we
   --  handle SIGINT ourselves so it can be attached as a graceful exit.
   pragma Interrupt_State
     (Name  => Ada.Interrupts.Names.SIGINT,
      State => User);

   Flag : Boolean := False;
   pragma Volatile (Flag);

   protected Signal_Handler is
      procedure Handle;
      pragma Interrupt_Handler (Handle);
   end Signal_Handler;

end Graceful_Shutdown;
