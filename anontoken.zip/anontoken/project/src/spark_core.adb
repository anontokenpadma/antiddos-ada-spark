package body Spark_Core is
   pragma SPARK_Mode (On);

   package body Http_Parser is

      function Is_Digit (B : Byte) return Boolean is
        (B >= Byte (Character'Pos ('0')) and then B <= Byte (Character'Pos ('9')));

      function Is_Upper (B : Byte) return Boolean is
        (B >= Byte (Character'Pos ('A')) and then B <= Byte (Character'Pos ('Z')));

      function Is_Token_Char (B : Byte) return Boolean is
        (B >= Byte (Character'Pos ('!')) and then B <= Byte (Character'Pos ('~'))
         and then B /= Byte (Character'Pos (ASCII.DEL)));

      function Is_Value_Char (B : Byte) return Boolean is
        (B = Byte (Character'Pos (ASCII.HT)) or else
         (B >= Byte (Character'Pos (' ')) and then
          B /= Byte (Character'Pos (ASCII.DEL))));

      function Is_Uri_Char (B : Byte) return Boolean is
        (B >= Byte (Character'Pos ('!')) and then B <= Byte (Character'Pos ('~'))
         and then B /= Byte (Character'Pos ('#')));

      function Char_Upper (B : Byte) return Byte is
        (if B >= Byte (Character'Pos ('a')) and then B <= Byte (Character'Pos ('z'))
         then B - 32 else B);

      function Char_Equal_CI (B : Byte; C : Character) return Boolean is
        (Char_Upper (B) = Char_Upper (Byte (Character'Pos (C))));

      function Matches
        (Buf : Head_Buffer; Pos : SEO; S : String) return Boolean
      is
      begin
         if Pos < Buf'First
           or else SEO (S'Length) > Buf'Last - Pos + 1
         then
            return False;
         end if;
         for K in S'Range loop
            if Buf (Pos + SEO (K - S'First)) /= Byte (Character'Pos (S (K))) then
               return False;
            end if;
            pragma Loop_Invariant
              (Pos + SEO (K - S'First) in Pos .. Pos + SEO (S'Length) - 1);
         end loop;
         return True;
      end Matches;

      function Matches_CI
        (Buf : Head_Buffer; Pos : SEO; S : String) return Boolean
      is
      begin
         if Pos < Buf'First
           or else SEO (S'Length) > Buf'Last - Pos + 1
         then
            return False;
         end if;
         for K in S'Range loop
            if not Char_Equal_CI (Buf (Pos + SEO (K - S'First)), S (K)) then
               return False;
            end if;
            pragma Loop_Invariant
              (Pos + SEO (K - S'First) in Pos .. Pos + SEO (S'Length) - 1);
         end loop;
         return True;
      end Matches_CI;

      function Name_Matches
        (Buf : Head_Buffer; S, L : SEO; Name : String) return Boolean
      is
      begin
         if S < Buf'First or else L > Buf'Last or else L < S then
            return False;
         end if;
         if L - S + 1 /= SEO (Name'Length) then
            return False;
         end if;
         for K in Name'Range loop
            if not Char_Equal_CI (Buf (S + SEO (K - Name'First)), Name (K)) then
               return False;
            end if;
            pragma Loop_Invariant (S + SEO (K - Name'First) in S .. L);
         end loop;
         return True;
      end Name_Matches;

      function Find_Byte
        (Buf : Head_Buffer; S, L : SEO; C : Byte) return SEO
      is
      begin
         if S < Buf'First or else L > Buf'Last or else S > L + 1 then
            return 0;
         end if;
         for I in S .. L loop
            if Buf (I) = C then
               return I;
            end if;
            pragma Loop_Invariant (I in S .. L);
         end loop;
         return 0;
      end Find_Byte;

      function Contains_Token_CI
        (Buf : Head_Buffer; S, L : SEO; Tok : String) return Boolean
      is
         I : SEO := S;
      begin
         if S < Buf'First or else L > Buf'Last or else S > L then
            return False;
         end if;
         while I <= L loop
            pragma Loop_Invariant (I in S .. L + 1);
            pragma Loop_Variant (Increases => I);
            if Buf (I) = Byte (Character'Pos (','))
              or else Buf (I) = Byte (Character'Pos (' '))
              or else Buf (I) = Byte (Character'Pos (ASCII.HT))
            then
               I := I + 1;
            else
               declare
                  J : SEO := I;
               begin
                  while J <= L
                    and then Buf (J) /= Byte (Character'Pos (','))
                    and then Buf (J) /= Byte (Character'Pos (' '))


                    and then Buf (J) /= Byte (Character'Pos (ASCII.HT))
                  loop
                     pragma Loop_Invariant (J in I .. L + 1);
                     pragma Loop_Variant (Increases => J);
                     J := J + 1;
                  end loop;
                  if J - I = SEO (Tok'Length)
                    and then Matches_CI (Buf, I, Tok)
                  then
                     return True;
                  end if;
                  I := J + 1;
               end;
            end if;
         end loop;
         return False;
      end Contains_Token_CI;

      type Decimal_Result is record
         Valid   : Boolean := False;
         Value   : Natural := 0;
      end record;

      Clamp_Max : constant := 1_000_000_000;
      Clamp_Sentinel : constant Natural := 1_000_000_001;

      function Parse_Decimal
        (Buf : Head_Buffer; S, L : SEO) return Decimal_Result
      is
         Res : Decimal_Result;
         V : Long_Long_Integer := 0;
      begin
         if S > L then
            return Res;
         end if;
         for I in S .. L loop
            if not Is_Digit (Buf (I)) then
               return Res;
            end if;
            V := V * 10 + Long_Long_Integer (Buf (I) - 48);
            pragma Loop_Invariant (V >= 0);
            if V > Clamp_Max then
               Res.Valid := True;
               Res.Value := Clamp_Sentinel;
               return Res;
            end if;
         end loop;
         Res.Valid := True;
         Res.Value := Natural (V);
         return Res;
      end Parse_Decimal;

      function Find_Head_End
        (Buf : Head_Buffer; Start, Last : SEO) return SEO
      is
      begin
         if Start > Last or else Start < Buf'First or else Last > Buf'Last then
            return 0;
         end if;
         for I in Start .. Last - 1 loop
            pragma Loop_Invariant (I in Start .. Last - 1);
            if I + 3 <= Last
              and then Buf (I) = 13 and then Buf (I + 1) = 10
              and then Buf (I + 2) = 13 and then Buf (I + 3) = 10
            then
               return I + 3;
            end if;
            if I + 1 <= Last
              and then Buf (I) = 10 and then Buf (I + 1) = 10
            then
               return I + 1;
            end if;
         end loop;
         return 0;
      end Find_Head_End;

      function Parse_Hex
        (Buf : Chunk_Line_Buf; Start, Last : SEO) return Natural
      is
         V : Long_Long_Integer := 0;
         D : Long_Long_Integer;
      begin
         if Start < Buf'First or else Last > Buf'Last or else Start > Last then
            return 0;
         end if;
         for I in Start .. Last loop
            pragma Loop_Invariant (V >= 0
                                   and then V <= Long_Long_Integer (Natural'Last));
            exit when Buf (I) = Byte (Character'Pos (';'))
              or else Buf (I) = 13 or else Buf (I) = 10;
            if Is_Digit (Buf (I)) then
               D := Long_Long_Integer (Buf (I) - 48);
            elsif Buf (I) >= Byte (Character'Pos ('a'))
              and then Buf (I) <= Byte (Character'Pos ('f'))
            then
               D := Long_Long_Integer (Buf (I) - 87);
            elsif Buf (I) >= Byte (Character'Pos ('A'))
              and then Buf (I) <= Byte (Character'Pos ('F'))
            then
               D := Long_Long_Integer (Buf (I) - 55);
            else
               return 0;
            end if;
            V := V * 16 + D;
            if V > Long_Long_Integer (Natural'Last) then
               return 0;
            end if;
         end loop;
         return Natural (V);
      end Parse_Hex;

      function Parse_Request_Line
        (Buf : Head_Buffer; Start, Last : SEO) return Line_Info
      is
         Res : Line_Info;
         Line_End : SEO;
         Cont_Last : SEO;
         I : SEO;
         M_Len : SEO;
      begin
         if Start < Buf'First or else Last > Buf'Last or else Start > Last then
            return Res;
         end if;
         Line_End := Find_Byte (Buf, Start, Last, 10);
         if Line_End = 0 then
            return Res;
         end if;
         Res.Line_End := Line_End;
         Cont_Last := Line_End - 1;
         if Cont_Last >= Start and then Buf (Cont_Last) = 13 then
            Cont_Last := Cont_Last - 1;
         end if;
         if Cont_Last < Start then
            return Res;
         end if;
         --  Method: run of uppercase letters
         I := Start;
         while I <= Cont_Last and then Is_Upper (Buf (I)) loop
            pragma Loop_Invariant (I in Start .. Cont_Last + 1);
            pragma Loop_Variant (Increases => I);
            I := I + 1;
         end loop;
         M_Len := I - Start;
         if M_Len < 3 or else M_Len > 7 then
            return Res;
         end if;
         if M_Len = 3 and then Matches (Buf, Start, "GET") then
            Res.Method := M_GET;
         elsif M_Len = 4 and then Matches (Buf, Start, "POST") then
            Res.Method := M_POST;
         elsif M_Len = 4 and then Matches (Buf, Start, "HEAD") then
            Res.Method := M_HEAD;
         elsif M_Len = 3 and then Matches (Buf, Start, "PUT") then
            Res.Method := M_PUT;
         elsif M_Len = 6 and then Matches (Buf, Start, "DELETE") then
            Res.Method := M_DELETE;
         elsif M_Len = 7 and then Matches (Buf, Start, "OPTIONS") then
            Res.Method := M_OPTIONS;
         elsif M_Len = 5 and then Matches (Buf, Start, "PATCH") then
            Res.Method := M_PATCH;
         else
            Res.Method := M_UNKNOWN;
         end if;
         if I > Cont_Last or else Buf (I) /= 32 then
            return Res;
         end if;
         while I <= Cont_Last and then Buf (I) = 32 loop
            pragma Loop_Invariant (I in Start .. Cont_Last + 1);
            pragma Loop_Variant (Increases => I);
            I := I + 1;
         end loop;
         --  URI
         if I > Cont_Last then
            return Res;
         end if;
         Res.Uri_Start := I;
         while I <= Cont_Last and then Is_Uri_Char (Buf (I)) loop
            pragma Loop_Invariant (I in Start .. Cont_Last + 1);
            pragma Loop_Variant (Increases => I);
            I := I + 1;
         end loop;
         Res.Uri_Last := I - 1;
         if Buf (Res.Uri_Start) /= Byte (Character'Pos ('/')) then
            return Res;
         end if;
         if I > Cont_Last or else Buf (I) /= 32 then
            return Res;
         end if;
         while I <= Cont_Last and then Buf (I) = 32 loop
            pragma Loop_Invariant (I in Start .. Cont_Last + 1);
            pragma Loop_Variant (Increases => I);
            I := I + 1;
         end loop;
         --  Version
         if I + 7 > Cont_Last then
            return Res;
         end if;
         if Matches (Buf, I, "HTTP/") then
            if Matches (Buf, I, "HTTP/1.0") then
               Res.Version := V_1_0;
               I := I + 8;
            elsif Matches (Buf, I, "HTTP/1.1") then
               Res.Version := V_1_1;
               I := I + 8;
            else
               Res.Version := V_UNKNOWN;
               I := Cont_Last + 1;
            end if;
         else
            return Res;
         end if;
         if I - 1 /= Cont_Last then
            return Res;
         end if;
         Res.Is_1_1 := Res.Version = V_1_1;
         Res.Valid := True;
         return Res;
      end Parse_Request_Line;

      function Scan_Headers
        (Buf : Head_Buffer; Start, Last : SEO) return Header_Info
      is
         Res : Header_Info;
         I : SEO := Start;
      begin
         Res.Valid := True;
         if Start < Buf'First or else Last > Buf'Last or else Start > Last then
            Res.Valid := False;
            return Res;
         end if;
         while I <= Last loop
            pragma Loop_Invariant (I in Start .. Last + 1);
            pragma Loop_Variant (Increases => I);
            --  Blank line ends the header block
            if Buf (I) = 10 then
               exit;
            end if;
            if Buf (I) = 13 and then I + 1 <= Last and then Buf (I + 1) = 10 then
               exit;
            end if;
            --  Reject obs-fold (continuation line)
            if Buf (I) = 32 or else Buf (I) = Byte (Character'Pos (ASCII.HT)) then
               Res.Valid := False;
               exit;
            end if;
            declare
               Line_End : constant SEO := Find_Byte (Buf, I, Last, 10);
               Colon : SEO;
               VStart, VEnd : SEO;
               Name_Ok : Boolean := True;
               Val_Ok : Boolean := True;
            begin
               if Line_End = 0 then
                  Res.Valid := False;
                  exit;
               end if;
               Colon := Find_Byte (Buf, I, Line_End - 1, Byte (Character'Pos (':')));
               if Colon = 0 then
                  Res.Valid := False;
                  exit;
               end if;
               for K in I .. Colon - 1 loop
                  if not Is_Token_Char (Buf (K)) then
                     Name_Ok := False;
                  end if;
                  pragma Loop_Invariant (K in I .. Colon - 1);
               end loop;
               VStart := Colon + 1;
               while VStart <= Line_End - 1
                 and then (Buf (VStart) = 32
                           or else Buf (VStart) = Byte (Character'Pos (ASCII.HT)))
               loop
                  pragma Loop_Invariant (VStart in Colon + 1 .. Line_End);
                  pragma Loop_Variant (Increases => VStart);
                  VStart := VStart + 1;
               end loop;
               VEnd := Line_End - 1;
               if VEnd >= VStart and then Buf (VEnd) = 13 then
                  VEnd := VEnd - 1;
               end if;
               while VEnd >= VStart
                 and then (Buf (VEnd) = 32
                           or else Buf (VEnd) = Byte (Character'Pos (ASCII.HT)))
               loop
                  pragma Loop_Invariant (VEnd in VStart - 1 .. Line_End - 1);
                  pragma Loop_Variant (Decreases => VEnd);
                  VEnd := VEnd - 1;
               end loop;
               for K in VStart .. VEnd loop
                  if not Is_Value_Char (Buf (K)) then
                     Val_Ok := False;
                  end if;
                  pragma Loop_Invariant (K in VStart .. VEnd);
               end loop;
               if not Name_Ok or else not Val_Ok then
                  Res.Valid := False;
                  exit;
               end if;
               if Name_Matches (Buf, I, Colon - 1, "host") then
                  if VEnd < VStart then
                     Res.Valid := False;
                     exit;
                  end if;
                  if Res.Has_Host then
                     --  RFC 7230 5.4: a request with more than one Host
                     --  header field is invalid; reject it.
                     Res.Valid := False;
                     exit;
                  end if;
                  Res.Has_Host := True;
               elsif Name_Matches (Buf, I, Colon - 1, "content-length") then
                  if Res.Has_Content_Length then
                     Res.Valid := False;
                     exit;
                  end if;
                  declare
                     D : constant Decimal_Result := Parse_Decimal (Buf, VStart, VEnd);
                  begin
                     if not D.Valid then
                        Res.Valid := False;
                        exit;
                     end if;
                     Res.Has_Content_Length := True;
                     Res.Content_Length := D.Value;
                  end;
               elsif Name_Matches (Buf, I, Colon - 1, "transfer-encoding") then
                  if Contains_Token_CI (Buf, VStart, VEnd, "chunked") then
                     if Res.Chunked then
                        Res.Valid := False;
                        exit;
                     end if;
                     Res.Chunked := True;
                  else
                     Res.Bad_Transfer_Encoding := True;
                  end if;
               elsif Name_Matches (Buf, I, Colon - 1, "connection") then
                  if Contains_Token_CI (Buf, VStart, VEnd, "close") then
                     Res.Has_Close := True;
                  end if;
                  if Contains_Token_CI (Buf, VStart, VEnd, "keep-alive") then
                     Res.Has_Keep_Alive := True;
                  end if;
               elsif Name_Matches (Buf, I, Colon - 1, "expect") then
                  if Contains_Token_CI (Buf, VStart, VEnd, "100-continue") then
                     Res.Expect_100 := True;
                  end if;
               end if;
               I := Line_End + 1;
            end;
         end loop;
         return Res;
      end Scan_Headers;

      function Parse_Response
        (Buf : Head_Buffer; Start, Last : SEO; Method_Is_Head : Boolean)
         return Response_Info
      is
         Res : Response_Info;
         Line_End : SEO;
         I : SEO;
         Hdrs : Header_Info;
      begin
         if Start < Buf'First or else Last > Buf'Last or else Start > Last then
            return Res;
         end if;
         Line_End := Find_Byte (Buf, Start, Last, 10);
         if Line_End = 0 or else Line_End - Start < 11 then
            return Res;
         end if;
         if not Matches (Buf, Start, "HTTP/") then
            return Res;
         end if;
         if not Is_Digit (Buf (Start + 5)) or else Buf (Start + 6) /= 46
           or else not Is_Digit (Buf (Start + 7))
         then
            return Res;
         end if;
         I := Start + 8;
         if Buf (I) /= 32 then
            return Res;
         end if;
         if I + 3 > Line_End - 1 then
            return Res;
         end if;
         if not Is_Digit (Buf (I + 1)) or else not Is_Digit (Buf (I + 2))
           or else not Is_Digit (Buf (I + 3))
         then
            return Res;
         end if;
         Res.Status := Natural (Buf (I + 1) - 48) * 100
                     + Natural (Buf (I + 2) - 48) * 10
                     + Natural (Buf (I + 3) - 48);
         Res.Valid := True;
         Res.Is_1xx := Res.Status in 100 .. 199;
         Hdrs := Scan_Headers (Buf, Line_End + 1, Last);
         if not Hdrs.Valid then
            Res.Valid := False;
            return Res;
         end if;
         Res.Connection_Close := Hdrs.Has_Close;
         if Method_Is_Head or else Res.Status in 100 .. 199
           or else Res.Status = 204 or else Res.Status = 304
         then
            Res.Frame_Kind := Frame_None;
         elsif Hdrs.Chunked then
            Res.Frame_Kind := Frame_Chunked;
         elsif Hdrs.Has_Content_Length then
            Res.Frame_Kind := Frame_By_Length;
            Res.Body_Length := Hdrs.Content_Length;
         else
            Res.Frame_Kind := Frame_Close;
         end if;
         return Res;
      end Parse_Response;

   end Http_Parser;

   package body Rate_Limiter is

      Max_Elapsed : constant Time_Count := 3600;

      function Find
        (T : Bucket_Table; IP : IP_Addr) return Bucket_Index
      is
      begin
         for I in Table_Index loop
            if T (I).Active and then T (I).IP = IP then
               return I;
            end if;
            pragma Loop_Invariant (I in Table_Index'First .. Table_Index'Last);
         end loop;
         return Not_Found;
      end Find;

      function Find_Free_Or_Evict (T : Bucket_Table) return Table_Index is
         Min_I : Table_Index := 0;
      begin
         for I in Table_Index loop
            if not T (I).Active then
               return I;
            end if;
            pragma Loop_Invariant (I in Table_Index'First .. Table_Index'Last);
         end loop;
         for I in Table_Index'Succ (Table_Index'First) .. Table_Index'Last loop
            if T (I).Last < T (Min_I).Last then
               Min_I := I;
            end if;
            pragma Loop_Invariant (Min_I in Table_Index'First .. Table_Index'Last);
         end loop;
         return Min_I;
      end Find_Free_Or_Evict;

      procedure Consume
        (T       : in out Bucket_Table;
         IP      : IP_Addr;
         Now     : Time_Count;
         Rate    : Token_Count;
         Burst   : Token_Count;
         Allowed : out Boolean)
      is
         Idx : Bucket_Index;
      begin
         Idx := Find (T, IP);
         if Idx = Not_Found then
            Idx := Find_Free_Or_Evict (T);
            T (Idx) := (Active => True, IP => IP,
                        Tokens => Burst - 1, Last => Now);
            Allowed := True;
         else
            declare
               Elapsed : Token_Count;
               Added   : Token_Count;
            begin
               if Now >= T (Idx).Last then
                  if Now - T (Idx).Last >= Max_Elapsed then
                     Elapsed := Token_Count (Max_Elapsed);
                  else
                     Elapsed := Token_Count (Now - T (Idx).Last);
                  end if;
               else
                  Elapsed := 0;
               end if;
               Added := Elapsed * Rate;
               T (Idx).Tokens := Token_Count'Min (Burst, T (Idx).Tokens + Added);
               T (Idx).Last := Now;
               if T (Idx).Tokens >= 1 then
                  T (Idx).Tokens := T (Idx).Tokens - 1;
                  Allowed := True;
               else
                  Allowed := False;
               end if;
            end;
         end if;
      end Consume;

      function Retry_After
        (T : Bucket_Table; IP : IP_Addr; Now : Time_Count; Rate : Token_Count)
         return Natural
      is
         Idx : constant Bucket_Index := Find (T, IP);
         Tok : Token_Count;
         Elapsed : Token_Count;
      begin
         if Idx = Not_Found then
            return 0;
         end if;
         Tok := T (Idx).Tokens;
         if Now >= T (Idx).Last then
            if Now - T (Idx).Last >= Max_Elapsed then
               Elapsed := Token_Count (Max_Elapsed);
            else
               Elapsed := Token_Count (Now - T (Idx).Last);
            end if;
            Tok := Token_Count'Min (1_000_000,
                                    Tok + Elapsed * Rate);
         end if;
         if Tok >= 1 then
            return 0;
         end if;
         return Natural ((1 - Tok) / Rate) + 1;
      end Retry_After;

      procedure Consume_Global
        (B       : in out Bucket;
         Now     : Time_Count;
         Rate    : Token_Count;
         Burst   : Token_Count;
         Allowed : out Boolean)
      is
         Elapsed : Token_Count;
         Added   : Token_Count;
      begin
         --  first use: start the shared bucket full (same as a new
         --  per-IP bucket) so a freshly started proxy is not 429-ing
         --  everything within the first second
         if not B.Active then
            B := (Active => True, IP => (others => 0),
                  Tokens => Burst - 1, Last => Now);
            Allowed := True;
            return;
         end if;
         if Now >= B.Last then
            if Now - B.Last >= Max_Elapsed then
               Elapsed := Token_Count (Max_Elapsed);
            else
               Elapsed := Token_Count (Now - B.Last);
            end if;
         else
            Elapsed := 0;
         end if;
         Added := Elapsed * Rate;
         if B.Tokens >= Burst then
            B.Tokens := Burst;
         elsif Added >= Burst or else B.Tokens + Added > Burst then
            B.Tokens := Burst;
         else
            B.Tokens := B.Tokens + Added;
         end if;
         B.Last := Now;
         if B.Tokens >= 1 then
            B.Tokens := B.Tokens - 1;
            Allowed := True;
         else
            Allowed := False;
         end if;
      end Consume_Global;

      function Global_Retry_After
        (B : Bucket; Now : Time_Count; Rate : Token_Count) return Natural
      is
         Tok     : Token_Count := B.Tokens;
         Elapsed : Token_Count := 0;
         Added   : Token_Count;
      begin
         if not B.Active then
            return 0;
         end if;
         if Now >= B.Last then
            if Now - B.Last >= Max_Elapsed then
               Elapsed := Token_Count (Max_Elapsed);
            else
               Elapsed := Token_Count (Now - B.Last);
            end if;
         end if;
         Added := Elapsed * Rate;
         if Tok >= 1_000_000 then
            Tok := 1_000_000;
         elsif Added >= 1_000_000 or else Tok + Added >= 1_000_000 then
            Tok := 1_000_000;
         else
            Tok := Tok + Added;
         end if;
         if Tok >= 1 then
            return 0;
         end if;
         return Natural ((1 - Tok) / Rate) + 1;
      end Global_Retry_After;

   end Rate_Limiter;

   package body Errors is

      function Code_Of (Kind : Error_Kind) return Natural is
        (case Kind is
            when E_Bad_Request => 400,
            when E_Method_Not_Allowed => 405,
            when E_Timeout => 408,
            when E_Payload_Too_Large => 413,
            when E_Uri_Too_Long => 414,
            when E_Too_Many_Requests => 429,
            when E_Header_Too_Large => 431,
            when E_Not_Implemented => 501,
            when E_Unavailable => 503,
            when E_Bad_Gateway => 502,
            when E_Gateway_Timeout => 504,
            when E_Version_Not_Supported => 505);

      function Reason_Of (Kind : Error_Kind) return String
        with Post => Reason_Of'Result'Length <= 33;

      function Reason_Of (Kind : Error_Kind) return String is
        (case Kind is
            when E_Bad_Request => "Bad Request",
            when E_Method_Not_Allowed => "Method Not Allowed",
            when E_Timeout => "Request Timeout",
            when E_Payload_Too_Large => "Payload Too Large",
            when E_Uri_Too_Long => "URI Too Long",
            when E_Too_Many_Requests => "Too Many Requests",
            when E_Header_Too_Large => "Request Header Fields Too Large",
            when E_Not_Implemented => "Not Implemented",
            when E_Unavailable => "Service Unavailable",
            when E_Bad_Gateway => "Bad Gateway",
            when E_Gateway_Timeout => "Gateway Timeout",
            when E_Version_Not_Supported => "HTTP Version Not Supported");

      procedure Put
        (Buf : in out Error_Buffer; Pos : in out SEO; S : String)
        with
          Pre  =>
            Pos >= Buf'First
              and then Pos <= Buf'Last
              and then SEO (S'Length) <= Buf'Last - Pos + 1,
          Post => Pos = Pos'Old + SEO (S'Length);

      procedure Put
        (Buf : in out Error_Buffer; Pos : in out SEO; S : String)
      is
         Init : constant SEO := Pos;
      begin
         for I in S'Range loop
            pragma Loop_Invariant
              (Pos >= Buf'First
               and then Pos <= Buf'Last + 1
               and then Pos = Init + SEO (I - S'First + 1) - 1);
            Buf (Pos) := Byte (Character'Pos (S (I)));
            Pos := Pos + 1;
         end loop;
      end Put;

      procedure Put_Int
        (Buf : in out Error_Buffer; Pos : in out SEO; V : Natural)
        with
          Pre  => Pos >= Buf'First and then Pos <= Buf'Last - 10,
          Post => Pos >= Buf'First and then Pos <= Pos'Old + 11;

      procedure Put_Int
        (Buf : in out Error_Buffer; Pos : in out SEO; V : Natural)
      is
         Digs : String (1 .. 10) := [others => ' '];
         N : Natural := V;
         D : Natural := 0;
         Init : constant SEO := Pos;
      begin
         if V = 0 then
            Buf (Pos) := 48;
            Pos := Pos + 1;
            return;
         end if;
         while N > 0 and then D < 10 loop
            D := D + 1;
            Digs (D) := Character'Val (48 + N mod 10);
            N := N / 10;
            pragma Loop_Invariant (D in 1 .. 10 and then N >= 0);
         end loop;
         for K in reverse 1 .. D loop
            Buf (Pos) := Byte (Character'Pos (Digs (K)));
            Pos := Pos + 1;
            pragma Loop_Invariant
              (Pos >= Buf'First
               and then Pos = Init + SEO (D - K + 1)
               and then Pos <= Buf'Last);
         end loop;
      end Put_Int;

      procedure Build
        (Kind        : Error_Kind;
         Retry_After : Natural;
         Buf         : in out Error_Buffer;
         Len         : out SEO)
      is
         Pos : SEO := Buf'First;
         Reason : constant String := Reason_Of (Kind);
         Body_T : constant String := Natural'Image (Code_Of (Kind))
                   & " " & Reason & ASCII.LF;
         Code : constant Natural := Code_Of (Kind);
      begin
         Put (Buf, Pos, "HTTP/1.1 ");
         Put_Int (Buf, Pos, Code);
         Put (Buf, Pos, " ");
         Put (Buf, Pos, Reason);
         Put (Buf, Pos, ASCII.CR & ASCII.LF);
         if Kind = E_Too_Many_Requests then
            Put (Buf, Pos, "Retry-After: ");
            Put_Int (Buf, Pos, Retry_After);
            Put (Buf, Pos, ASCII.CR & ASCII.LF);
         end if;
         if Kind = E_Method_Not_Allowed then
            Put (Buf, Pos,
                 "Allow: GET, POST, PUT, DELETE, HEAD, OPTIONS, PATCH"
                 & ASCII.CR & ASCII.LF);
         end if;
         Put (Buf, Pos, "Content-Type: text/plain" & ASCII.CR & ASCII.LF);
         Put (Buf, Pos, "Content-Length: ");
         Put_Int (Buf, Pos, Body_T'Length);
         Put (Buf, Pos, ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF);
         Put (Buf, Pos, Body_T);
         Len := Pos - 1;
      end Build;

   end Errors;

   package body Cli is

      function Parse_Unsigned (S : String; Max : Natural) return Natural is
         V : Long_Long_Integer := 0;
         Started : Boolean := False;
      begin
         for K in S'Range loop
            pragma Loop_Invariant
              (V >= 0 and then V <= Long_Long_Integer (Max));
            if S (K) in '0' .. '9' then
               Started := True;
               pragma Assert (V <= Long_Long_Integer (Natural'Last));
               V := V * 10 + Long_Long_Integer (Character'Pos (S (K)) - 48);
               if V > Long_Long_Integer (Max) then
                  return 0;
               end if;
            elsif S (K) = ' ' then
               null;  -- tolerate stray spaces
            else
               return 0;
            end if;
         end loop;
         if not Started or else V = 0 then
            return 0;
         end if;
         pragma Assert (V <= Long_Long_Integer (Natural'Last));
         return Natural (V);
      end Parse_Unsigned;

      function Parse_Args (A1, A2, A3 : String) return Args_Info is
         Res : Args_Info;
         Ok_Host : Boolean := True;
      begin
         Res.Listen_Port := Parse_Unsigned (A1, 65535);
         Res.Target_Port := Parse_Unsigned (A3, 65535);
         if A2'Length < 1 or else A2'Length > Max_Host_Len then
            Ok_Host := False;
         else
            for K in A2'Range loop
               if A2 (K) < Character'Val (33) or else A2 (K) > Character'Val (126) then
                  Ok_Host := False;
               end if;
            end loop;
         end if;
         if Res.Listen_Port = 0 or else Res.Target_Port = 0 or else not Ok_Host then
            return Res;
         end if;
         Res.Host_Len := A2'Length;
         for K in A2'Range loop
            Res.Host (K - A2'First + 1) := A2 (K);
         end loop;
         Res.Ok := True;
         return Res;
      end Parse_Args;

      function Load_Config return Config_Type is
         C : Config_Type;
         V : Natural;
      begin
         V := Parse_Unsigned (IO.Get_Env ("RC_RATE"), 10_000);
         if V /= 0 then
            C.Rate := V;
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_BURST"), 1_000_000);
         if V /= 0 then
            C.Burst := V;
         end if;
         if C.Burst < C.Rate then
            C.Burst := C.Rate;
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_GLOBAL_RPS"), 10_000);
         if V /= 0 then
            C.Global_RPS := V;
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_MAX_PER_IP"), 10_000);
         if V /= 0 then
            C.Max_Per_IP := V;
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_MAX_TOTAL"), 100_000);
         if V /= 0 then
            C.Max_Total := V;
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_MAX_BODY_MB"), 64);
         if V /= 0 then
            C.Max_Body := V * 1024 * 1024;
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_MAX_REQS"), 10_000);
         if V /= 0 then
            C.Max_Reqs := V;
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_HEADER_TIMEOUT"), 300);
         if V /= 0 then
            C.Header_Timeout := Duration (V);
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_IDLE_TIMEOUT"), 3600);
         if V /= 0 then
            C.Idle_Timeout := Duration (V);
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_BACKEND_TIMEOUT"), 3600);
         if V /= 0 then
            C.Backend_Timeout := Duration (V);
         end if;
         V := Parse_Unsigned (IO.Get_Env ("RC_CONNECT_TIMEOUT"), 300);
         if V /= 0 then
            C.Connect_Timeout := Duration (V);
         end if;
         return C;
      end Load_Config;

   end Cli;

   package body IO is
      function Get_Env (Name : String) return String is
      begin
         pragma Unreferenced (Name);
         return "";
      end Get_Env;
   end IO;

end Spark_Core;
