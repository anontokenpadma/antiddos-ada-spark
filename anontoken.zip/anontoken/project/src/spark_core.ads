with Ada.Streams;

package Spark_Core is
   pragma SPARK_Mode (On);

   use type Ada.Streams.Stream_Element;
   use type Ada.Streams.Stream_Element_Array;
   use type Ada.Streams.Stream_Element_Offset;

   subtype Byte is Ada.Streams.Stream_Element;
   subtype Byte_Array is Ada.Streams.Stream_Element_Array;
   subtype SEO is Ada.Streams.Stream_Element_Offset;

   Max_Head_Size    : constant SEO := 16 * 1024;
   Max_Uri_Size     : constant SEO := 8 * 1024;
   Max_Chunk_Line   : constant SEO := 1 * 1024;
   Max_Error_Buf    : constant SEO := 1024;
   Rly_Size         : constant SEO := 16 * 1024;
   Reader_Buf_Size  : constant SEO := 16 * 1024;
   Max_Buckets      : constant := 4096;

   subtype Head_Buffer is Byte_Array (1 .. Max_Head_Size);
   subtype Chunk_Line_Buf is Byte_Array (1 .. Max_Chunk_Line);
   subtype Error_Buffer is Byte_Array (1 .. Max_Error_Buf);

   type Config_Type is record
      Rate            : Positive := 20;               -- tokens per second per IP
      Burst           : Positive := 40;               -- token bucket capacity
      Global_RPS      : Positive := 300;              -- max requests per second, total
      Max_Per_IP      : Positive := 16;               -- max concurrent conns per IP
      Max_Total       : Positive := 384;              -- max concurrent conns total
      --  (kept below the default 1024 FD ulimit so the accept loop rejects
      --  cleanly with 503 instead of exhausting file descriptors)
      Max_Body        : Natural  := 4 * 1024 * 1024;  -- max request body size
      Max_Reqs        : Positive := 200;              -- max requests per connection
      Header_Timeout  : Duration := 10.0;             -- request head read (slowloris)
      Idle_Timeout    : Duration := 30.0;             -- keep-alive idle timeout
      Backend_Timeout : Duration := 30.0;             -- backend read/send timeout
      Connect_Timeout : Duration := 5.0;              -- backend connect timeout
   end record;

   --  ===================== Http_Parser (SPARK) =====================

   package Http_Parser is

      type Http_Method is
        (M_GET, M_POST, M_PUT, M_DELETE, M_HEAD, M_OPTIONS, M_PATCH, M_UNKNOWN);

      type Http_Version is (V_1_0, V_1_1, V_UNKNOWN);

      type Line_Info is record
         Valid     : Boolean := False;
         Method    : Http_Method := M_UNKNOWN;
         Version   : Http_Version := V_UNKNOWN;
         Uri_Start : SEO := 0;
         Uri_Last  : SEO := 0;
         Line_End  : SEO := 0;    -- index of LF that ends the request line
         Is_1_1    : Boolean := False;
      end record;

      type Header_Info is record
         Valid          : Boolean := False;
         Has_Host       : Boolean := False;
         Has_Content_Length : Boolean := False;
         Content_Length : Natural := 0;   -- sentinel 1_000_000_001 if clamped
         Chunked        : Boolean := False;
         Bad_Transfer_Encoding : Boolean := False;
         Expect_100     : Boolean := False;
         Has_Close      : Boolean := False;
         Has_Keep_Alive : Boolean := False;
      end record;

      type Framing is (Frame_By_Length, Frame_Chunked, Frame_Close, Frame_None);

      type Response_Info is record
         Valid           : Boolean := False;
         Status          : Natural := 0;
         Is_1xx          : Boolean := False;
         Frame_Kind      : Framing := Frame_None;
         Body_Length     : Natural := 0;
         Connection_Close : Boolean := False;
      end record;

      function Find_Head_End
        (Buf : Head_Buffer; Start, Last : SEO) return SEO;
      --  Index of last byte of the blank-line terminator (CRLFCRLF or LFLF),
      --  or 0 when the terminator is not present in Buf (Start .. Last).

      function Parse_Request_Line
        (Buf : Head_Buffer; Start, Last : SEO) return Line_Info;
      --  Parse "METHOD SP URI SP HTTP/x.y" located at the start of the head.
      --  Last is the head end index as returned by Find_Head_End.

      function Scan_Headers
        (Buf : Head_Buffer; Start, Last : SEO) return Header_Info;
      --  Validate and extract fields from all header lines in [Start, Last].

      function Parse_Response
        (Buf : Head_Buffer; Start, Last : SEO; Method_Is_Head : Boolean)
         return Response_Info;
      --  Parse "HTTP/x.y STATUS ..." plus headers and derive body framing.

      function Parse_Hex
        (Buf : Chunk_Line_Buf; Start, Last : SEO) return Natural;
      --  Hex digits in [Start, Last] (stop at ';' or CR/LF); 0 if invalid.
      --  A leading '0' followed by ';'/CR/LF yields 0 (valid last-chunk).

      function Find_Byte
        (Buf : Head_Buffer; S, L : SEO; C : Byte) return SEO
        with Post => (Find_Byte'Result = 0)
          or else (Find_Byte'Result in S .. L
                   and then Buf (Find_Byte'Result) = C);
      --  First index in [S, L] holding C, or 0.

      function Name_Matches
        (Buf : Head_Buffer; S, L : SEO; Name : String) return Boolean;
      --  Case-insensitive comparison of Buf (S .. L) against Name.

   end Http_Parser;

   package Rate_Limiter is

      type IP_Addr is array (1 .. 4) of Byte;

      type Token_Count is range 0 .. 1_000_000_000;
      type Time_Count is range 0 .. 2**62;

      subtype Bucket_Index is Integer range -1 .. Max_Buckets - 1;
      subtype Table_Index is Bucket_Index range 0 .. Max_Buckets - 1;
      Not_Found : constant Bucket_Index := -1;

      type Bucket is record
         Active : Boolean := False;
         IP     : IP_Addr := [others => 0];
         Tokens : Token_Count := 0;
         Last   : Time_Count := 0;
      end record;

      type Bucket_Table is array (Table_Index) of Bucket;

      function Find
        (T : Bucket_Table; IP : IP_Addr) return Bucket_Index;

      procedure Consume
        (T       : in out Bucket_Table;
         IP      : IP_Addr;
         Now     : Time_Count;
         Rate    : Token_Count;
         Burst   : Token_Count;
         Allowed : out Boolean)
      with
        Pre => Rate >= 1 and then Rate <= 10_000
          and then Burst >= Rate and then Burst <= 1_000_000;

      function Retry_After
        (T : Bucket_Table; IP : IP_Addr; Now : Time_Count; Rate : Token_Count)
         return Natural
      with
        Pre => Rate >= 1 and then Rate <= 10_000;

      --  Global (all-IPs) token bucket: one shared bucket, so a
      --  distributed flood cannot exhaust the backend with total
      --  throughput even when no single IP exceeds its own limit.
      procedure Consume_Global
        (B       : in out Bucket;
         Now     : Time_Count;
         Rate    : Token_Count;
         Burst   : Token_Count;
         Allowed : out Boolean)
      with
        Pre => Rate >= 1 and then Rate <= 10_000
          and then Burst >= Rate and then Burst <= 1_000_000;

      function Global_Retry_After
        (B : Bucket; Now : Time_Count; Rate : Token_Count) return Natural
      with
        Pre => Rate >= 1 and then Rate <= 10_000;

   end Rate_Limiter;

   package Errors is

      type Error_Kind is
        (E_Bad_Request, E_Method_Not_Allowed, E_Timeout, E_Payload_Too_Large,
         E_Uri_Too_Long, E_Too_Many_Requests, E_Header_Too_Large,
         E_Not_Implemented, E_Unavailable, E_Bad_Gateway, E_Gateway_Timeout,
         E_Version_Not_Supported);

      procedure Build
        (Kind        : Error_Kind;
         Retry_After : Natural;
         Buf         : in out Error_Buffer;
         Len         : out SEO);

   end Errors;

   package Cli is

      Max_Host_Len : constant := 255;

      type Args_Info is record
         Ok          : Boolean := False;
         Listen_Port : Natural := 0;
         Target_Port : Natural := 0;
         Host_Len    : Natural := 0;
         Host        : String (1 .. Max_Host_Len) := [others => ' '];
      end record;

      function Parse_Unsigned (S : String; Max : Natural) return Natural
        with Post =>
          (if Parse_Unsigned'Result /= 0
           then Parse_Unsigned'Result in 1 .. Max);
      --  0 when S is not a valid decimal number in 1 .. Max.

      function Parse_Args (A1, A2, A3 : String) return Args_Info
        with Post =>
          (if Parse_Args'Result.Ok then
             Parse_Args'Result.Listen_Port in 1 .. 65535 and
             Parse_Args'Result.Target_Port in 1 .. 65535 and
             Parse_Args'Result.Host_Len  in 1 .. Max_Host_Len);

      function Load_Config return Config_Type;

   end Cli;

   package IO is
      function Get_Env (Name : String) return String;
   end IO;

end Spark_Core;
