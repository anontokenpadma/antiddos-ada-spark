#!/usr/bin/env python3
"""Deep multi-vector L7 DDoS attack simulation against the rideconnect proxy.

Simulates a determined attacker with many connections and payload tricks,
measuring what the proxy blocks vs. what leaks through, plus raw throughput
under flood.  Intended for local security testing only.
"""
import os
import signal
import socket
import subprocess
import sys
import threading
import time

BACKEND_PORT = 18110
BASE_PROXY_PORT = 18200
PROXY = "./bin/rideconnect"

PASS = 0
FAIL = 0
RESULTS = []  # (vector, blocked, detail)


def ok(name, blocked, detail=""):
    global PASS, FAIL
    if blocked:
        PASS += 1
    else:
        FAIL += 1
    RESULTS.append((name, blocked, detail))
    tag = "BLOCKED" if blocked else "LEAKED "
    print(f"  {tag}  {name}  {detail}")


# ---------------------------------------------------------------- backend

class Backend(threading.Thread):
    def __init__(self, port):
        super().__init__(daemon=True)
        self.port = port
        self.stop = False
        self.srv = None

    def run(self):
        self.srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("127.0.0.1", self.port))
        self.srv.listen(256)
        while not self.stop:
            try:
                conn, _ = self.srv.accept()
            except OSError:
                break
            threading.Thread(target=self.handle, args=(conn,), daemon=True).start()

    def close(self):
        self.stop = True
        try:
            self.srv.close()
        except Exception:
            pass

    def read_head(self, conn):
        data = b""
        while b"\r\n\r\n" not in data:
            c = conn.recv(4096)
            if not c:
                return None
            data += c
            if len(data) > 1_000_000:
                return None
        return data

    def handle(self, conn):
        try:
            conn.settimeout(3)
            data = self.read_head(conn)
            if data is None:
                conn.close()
                return
            conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
            conn.close()
        except Exception:
            try:
                conn.close()
            except Exception:
                pass


# ---------------------------------------------------------------- proxy

def start_proxy(env_extra=None, port=BASE_PROXY_PORT):
    env = dict(os.environ)
    if env_extra:
        env.update(env_extra)
    p = subprocess.Popen([PROXY, str(port), "127.0.0.1", str(BACKEND_PORT)],
                         env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(200):
        if p.poll() is not None:
            raise RuntimeError(f"proxy exited early (code {p.returncode})")
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=0.2)
            s.close()
            # confirm it is OUR proxy: send a request and expect a response
            try:
                s = socket.create_connection(("127.0.0.1", port), timeout=1.0)
                s.settimeout(1.0)
                s.sendall(b"GET /x HTTP/1.1\r\nHost: t\r\nConnection: close\r\n\r\n")
                d = s.recv(64)
                s.close()
                if d:
                    return p
            except OSError:
                pass
        except OSError:
            pass
        time.sleep(0.05)
    raise RuntimeError("proxy did not start")


def stop_proxy(p):
    try:
        p.send_signal(signal.SIGTERM)
        p.wait(timeout=3)
    except Exception:
        p.kill()


def status_of(raw):
    try:
        return int(raw.split(b"\r\n", 1)[0].split(b" ")[1])
    except Exception:
        return None


def one_req(port, payload, timeout=4):
    """Send one raw payload, return (status, raw)."""
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
        s.settimeout(timeout)
        s.sendall(payload)
        data = b""
        try:
            while True:
                c = s.recv(65536)
                if not c:
                    break
                data += c
        except socket.timeout:
            pass
        s.close()
        return status_of(data), data
    except (ConnectionRefusedError, ConnectionResetError, OSError, socket.timeout):
        return None, b""


# ================================================================ vectors

def vec_smuggling(port):
    """HTTP request smuggling variants -> must all be 400."""
    cases = [
        ("TE+CL", b"POST /x HTTP/1.1\r\nHost: t\r\nTransfer-Encoding: chunked\r\n"
                  b"Content-Length: 4\r\n\r\n0\r\n\r\n"),
        ("CL.TE (reverse)", b"POST /x HTTP/1.1\r\nHost: t\r\nContent-Length: 6\r\n"
                            b"Transfer-Encoding: chunked\r\n\r\n0\r\n\r\nG"),
        ("TE.TE repeated", b"POST /x HTTP/1.1\r\nHost: t\r\n"
                           b"Transfer-Encoding: chunked\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n"),
        ("CL+CL same", b"POST /x HTTP/1.1\r\nHost: t\r\nContent-Length: 5\r\n"
                       b"Content-Length: 5\r\n\r\nhello"),
        ("CL+CL diff", b"POST /x HTTP/1.1\r\nHost: t\r\nContent-Length: 5\r\n"
                       b"Content-Length: 6\r\n\r\nhello"),
        # OWS (SP/HTAB) after the colon is legal per RFC 7230; must be accepted
        ("CL with tab (legal OWS)", b"POST /x HTTP/1.1\r\nHost: t\r\nContent-Length:\t5\r\n\r\nhello"),
        # CL in a chunked trailer is body data, not a head header -> legal
        ("chunked trailer w/ CL (legal)", b"POST /x HTTP/1.1\r\nHost: t\r\n"
                                            b"Transfer-Encoding: chunked\r\n\r\n"
                                            b"0\r\nContent-Length: 5\r\n\r\nhello"),
    ]
    for name, payload in cases:
        st, _ = one_req(port, payload)
        # smuggling variants must be rejected; legal OWS/trailer cases accepted
        if "legal" in name:
            ok(f"smuggling: {name}", st == 200, f"got {st}")
        else:
            ok(f"smuggling: {name}", st == 400, f"got {st}")


def vec_injection(port):
    """CRLF / NUL / encoding tricks in request line and headers."""
    cases = [
        ("raw CRLF in URI", b"GET /x\r\nX-Evil: 1 HTTP/1.1\r\nHost: t\r\n\r\n"),
        ("NUL in URI", b"GET /x\x00y HTTP/1.1\r\nHost: t\r\n\r\n"),
        ("NUL in header value", b"GET /x HTTP/1.1\r\nHost: t\r\nX-Bad: a\x00b\r\n\r\n"),
        ("space in method", b"GE T /x HTTP/1.1\r\nHost: t\r\n\r\n"),
        ("tab in request line", b"GET\t/x\tHTTP/1.1\r\nHost: t\r\n\r\n"),
        ("header name with space", b"GET /x HTTP/1.1\r\nHost: t\r\nX Bad: 1\r\n\r\n"),
        ("header name with tab", b"GET /x HTTP/1.1\r\nHost: t\r\nX\tBad: 1\r\n\r\n"),
        ("double Host", b"GET /x HTTP/1.1\r\nHost: a\r\nHost: b\r\n\r\n"),
        ("Host empty value", b"GET /x HTTP/1.1\r\nHost: \r\n\r\n"),
    ]
    for name, payload in cases:
        st, _ = one_req(port, payload)
        # percent-encoded %0d%0a is path data (legal), not raw CRLF
        ok(f"injection: {name}", st in (400, 405, 414), f"got {st}")


def vec_method_abuse(port):
    """Random / dangerous methods."""
    for m in (b"CONNECT", b"TRACE", b"TRACK", b"PURGE", b"PROPFIND", b"MKCOL",
              b"LOCK", b"UNLOCK", b"DEBUG", b"get", b"POSTPOST", b"OPTIONS"):
        st, _ = one_req(port, m + b" /x HTTP/1.1\r\nHost: t\r\n\r\n")
        ok(f"method: {m.decode()}", st in (400, 405), f"got {st}")


def vec_oversized(port):
    """Oversized URI / header / body / chunk line."""
    uri = b"/" + b"a" * 9000
    st, _ = one_req(port, b"GET " + uri + b" HTTP/1.1\r\nHost: t\r\n\r\n")
    ok("URI 9KB -> 414", st == 414, f"got {st}")

    big = b"X-Big: " + b"a" * (20 * 1024) + b"\r\n"
    st, _ = one_req(port, b"GET /x HTTP/1.1\r\nHost: t\r\n" + big + b"\r\n")
    ok("header 20KB -> 431", st == 431, f"got {st}")

    # many small headers: 3000 x ~7B = ~21KB > 16KB head cap -> 431
    many = b"".join(b"X-H%d: %d\r\n" % (i, i) for i in range(3000))
    st, _ = one_req(port, b"GET /x HTTP/1.1\r\nHost: t\r\n" + many + b"\r\n")
    ok("3000 headers (21KB) -> 431", st == 431, f"got {st}")

    # chunk size line too long
    st, _ = one_req(port, b"POST /x HTTP/1.1\r\nHost: t\r\nTransfer-Encoding: chunked\r\n\r\n"
                           + b"9" * 2000 + b"\r\n\r\n")
    ok("chunk line 2KB -> 400", st == 400, f"got {st}")

    # bad chunk size
    st, _ = one_req(port, b"POST /x HTTP/1.1\r\nHost: t\r\nTransfer-Encoding: chunked\r\n\r\n"
                           + b"ZZZZ\r\n\r\n")
    ok("bad chunk size -> 400", st == 400, f"got {st}")

    # negative-looking chunk size
    st, _ = one_req(port, b"POST /x HTTP/1.1\r\nHost: t\r\nTransfer-Encoding: chunked\r\n\r\n"
                           + b"-5\r\n\r\n")
    ok("negative chunk size -> 400", st == 400, f"got {st}")


def vec_slow_body(port):
    """Slow POST: drip 1 byte every 300ms; with 1s header timeout the body
    phase should still be curtailed by the backend/read timeout."""
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=3)
        s.sendall(b"POST /x HTTP/1.1\r\nHost: t\r\nContent-Length: 100000\r\n\r\n")
        t0 = time.time()
        for i in range(30):
            try:
                s.sendall(b"a")
            except (BrokenPipeError, ConnectionResetError):
                break
            time.sleep(0.3)
        s.settimeout(2)
        data = b""
        try:
            while True:
                c = s.recv(4096)
                if not c:
                    break
                data += c
        except socket.timeout:
            pass
        s.close()
        elapsed = time.time() - t0
        # body read should time out (no backend 200 while body incomplete)
        blocked = b"200 OK" not in data
        ok("slow POST drip body", blocked, f"elapsed={elapsed:.1f}s got {status_of(data)}")
    except OSError:
        ok("slow POST drip body", True, "conn refused/closed")


def vec_keepalive_abuse(port):
    """Client sends a valid request then holds the keep-alive open."""
    held = []
    try:
        for _ in range(5):
            s = socket.create_connection(("127.0.0.1", port), timeout=3)
            s.sendall(b"GET /x HTTP/1.1\r\nHost: t\r\n\r\n")
            held.append(s)
        time.sleep(0.5)
        # proxy should still serve a fresh client (idle timeout default 30s)
        st, _ = one_req(port, b"GET /x HTTP/1.1\r\nHost: t\r\nConnection: close\r\n\r\n")
        ok("hold keep-alive open x5", st == 200, f"got {st}")
    finally:
        for s in held:
            try:
                s.close()
            except Exception:
                pass


def vec_conn_flood(port):
    """Open many simultaneous connections without sending anything (idle)."""
    socks = []
    try:
        for _ in range(30):
            s = socket.create_connection(("127.0.0.1", port), timeout=3)
            socks.append(s)
        time.sleep(0.3)
        # fresh client should still be served (per-IP cap 16 -> blocked)
        st, _ = one_req(port, b"GET /x HTTP/1.1\r\nHost: t\r\nConnection: close\r\n\r\n")
        ok("idle conn flood (30 hold)", st in (503, 400), f"got {st} (503=cap,400=reject)")
    finally:
        for s in socks:
            try:
                s.close()
            except Exception:
                pass


def vec_flood_rps(port, duration=3.0):
    """Volumetric flood: measure requests/sec and the 429 rate under load.

    Returns (rps, blocked_fraction) where blocked_fraction is the share of
    requests that got a defensive status (429/503/400...) vs 200.
    """
    stop = time.time() + duration
    counts = {"200": 0, "defended": 0}
    lock = threading.Lock()

    def worker():
        while time.time() < stop:
            try:
                st, _ = one_req(port, b"GET /x HTTP/1.1\r\nHost: t\r\nConnection: close\r\n\r\n",
                                timeout=2)
                with lock:
                    if st == 200:
                        counts["200"] += 1
                    else:
                        counts["defended"] += 1
            except Exception:
                pass

    threads = [threading.Thread(target=worker) for _ in range(16)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    total = counts["200"] + counts["defended"]
    rps = total / duration
    return rps, (counts["defended"] / total if total else 0.0), counts


def vec_dual_ip_flood(port):
    """Same as flood but also measures whether the token bucket is per-IP
    (here all from 127.0.0.1 so it should throttle hard)."""
    pass


# ================================================================ util

def run_section(name, fn, port):
    print(f"\n## {name}")
    fn(port)


def main():
    print("=" * 70)
    print("DEEP L7 DDoS ATTACK SIMULATION against ./bin/rideconnect")
    print("=" * 70)

    # kill any stray proxies from earlier runs so ports are free
    subprocess.run(["pkill", "-f", "bin/rideconnect"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.3)

    backend = Backend(BACKEND_PORT)
    backend.start()

    # ---- pass 1: default config ----
    print("\n>>> CONFIG: defaults (rate=20/s burst=40 max_per_ip=16 max_total=1024)")
    p = start_proxy({})
    time.sleep(0.3)
    try:
        run_section("Request smuggling", vec_smuggling, BASE_PROXY_PORT)
        run_section("Injection / encoding", vec_injection, BASE_PROXY_PORT)
        run_section("Method abuse", vec_method_abuse, BASE_PROXY_PORT)
        run_section("Oversized payloads", vec_oversized, BASE_PROXY_PORT)
        run_section("Slow POST (drip body)", vec_slow_body, BASE_PROXY_PORT)
        run_section("Keep-alive abuse", vec_keepalive_abuse, BASE_PROXY_PORT)
        run_section("Idle connection flood", vec_conn_flood, BASE_PROXY_PORT)
        print("\n## Volumetric flood (default config, 3s)")
        rps, frac, counts = vec_flood_rps(BASE_PROXY_PORT, 3.0)
        print(f"  throughput={rps:.0f} req/s | 200={counts['200']} defended={counts['defended']} "
              f"({frac*100:.0f}% defended)")
    finally:
        stop_proxy(p)

    # ---- pass 2: hardened config ----
    print("\n>>> CONFIG: hardened (rate=200/s burst=400 max_per_ip=64 max_total=4096)")
    H_PORT = BASE_PROXY_PORT + 2
    p = start_proxy({"RC_RATE": "200", "RC_BURST": "400", "RC_MAX_PER_IP": "64",
                     "RC_MAX_TOTAL": "4096", "RC_HEADER_TIMEOUT": "2"}, port=H_PORT)
    time.sleep(0.3)
    try:
        # run parsing vectors first (clean state), then flood, then recovery check
        run_section("Smuggling (hardened)", vec_smuggling, H_PORT)
        run_section("Injection (hardened)", vec_injection, H_PORT)
        print("\n## Volumetric flood (hardened config, 5s)")
        rps, frac, counts = vec_flood_rps(H_PORT, 5.0)
        print(f"  throughput={rps:.0f} req/s | 200={counts['200']} defended={counts['defended']} "
              f"({frac*100:.0f}% defended)")
        print("\n## Recovery after flood (1s drain)")
        time.sleep(1.0)
        st, _ = one_req(H_PORT,
                        b"GET /x HTTP/1.1\r\nHost: t\r\nConnection: close\r\n\r\n")
        ok("proxy serves again after flood", st == 200, f"got {st}")
    finally:
        stop_proxy(p)

    backend.close()

    print("\n" + "=" * 70)
    print(f"SUMMARY: {PASS} vectors blocked, {FAIL} leaked")
    for name, blocked, detail in RESULTS:
        print(f"  {'OK ' if blocked else 'LEAK'}  {name}  {detail}")
    print("=" * 70)


if __name__ == "__main__":
    main()
