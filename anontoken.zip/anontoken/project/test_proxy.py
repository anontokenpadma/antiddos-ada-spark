#!/usr/bin/env python3
"""Comprehensive end-to-end test suite for the rideconnect L7 DDoS proxy.

Backend + proxy are started locally; every protection feature and relay
behavior is exercised with raw sockets and HTTP clients.
"""
import hashlib
import os
import signal
import socket
import subprocess
import sys
import threading
import time

BACKEND_PORT = 18080
PROXY_PORT = 18090
PROXY = "./bin/rideconnect"
BIG_SIZE = 5 * 1024 * 1024  # 5 MB

PASS = 0
FAIL = 0
FAILURES = []


def ok(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}")
    else:
        FAIL += 1
        FAILURES.append(name)
        print(f"  FAIL  {name}  {extra}")


# ---------------------------------------------------------------- backend

class Backend(threading.Thread):
    """Minimal threaded HTTP backend with scripted routes."""

    def __init__(self, port):
        super().__init__(daemon=True)
        self.port = port
        self.stop = False
        self.srv = None

    def run(self):
        self.srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("127.0.0.1", self.port))
        self.srv.listen(128)
        while not self.stop:
            try:
                conn, _ = self.srv.accept()
            except OSError:
                break
            threading.Thread(target=self.handle, args=(conn,), daemon=True).start()

    def close(self):
        self.stop = True
        try:
            self.srv.close()
        except Exception:
            pass

    def read_head(self, conn):
        data = b""
        while b"\r\n\r\n" not in data and b"\n\n" not in data:
            chunk = conn.recv(4096)
            if not chunk:
                return None, None, None
            data += chunk
            if len(data) > 1_000_000:
                return None, None, None
        head, _, rest = data.partition(b"\r\n\r\n")
        if not head:
            head, _, rest = data.partition(b"\n\n")
        return head, rest, data

    def parse_head(self, head):
        lines = head.split(b"\r\n")
        if len(lines) == 1:
            lines = head.split(b"\n")
        req = lines[0].decode("latin1")
        headers = {}
        for ln in lines[1:]:
            if b":" in ln:
                k, _, v = ln.partition(b":")
                headers[k.strip().lower().decode("latin1")] = v.strip().decode("latin1")
        return req, headers

    def handle(self, conn):
        try:
            head, rest, data = self.read_head(conn)
            if head is None:
                conn.close()
                return
            req, headers = self.parse_head(head)
            method, path, _ = req.split(" ", 2) if req.count(" ") >= 2 else (req, "", "")
            if "?" in path:
                path = path.split("?", 1)[0]
            if headers.get("expect", "").lower() == "100-continue":
                conn.sendall(b"HTTP/1.1 100 Continue\r\n\r\n")
            body = b""
            if headers.get("transfer-encoding", "").lower() == "chunked":
                # read until terminator, decode chunks
                buf = rest if rest else b""
                total = 0
                while True:
                    line, _, buf = buf.partition(b"\r\n")
                    if not line:
                        while b"\r\n" not in buf:
                            c = conn.recv(4096)
                            if not c:
                                break
                            buf += c
                        line, _, buf = buf.partition(b"\r\n")
                    sz = int(line.strip().split(b";")[0], 16)
                    if sz == 0:
                        while b"\r\n\r\n" not in buf:
                            c = conn.recv(4096)
                            if not c:
                                break
                            buf += c
                        break
                    while len(buf) < sz + 2:
                        c = conn.recv(4096)
                        if not c:
                            break
                        buf += c
                    body += buf[:sz]
                    buf = buf[sz + 2:]
                    total += sz
                    if total > 20 * 1024 * 1024:
                        break
            elif "content-length" in headers:
                n = int(headers["content-length"])
                while len(body) < n:
                    if rest:
                        take = min(n - len(body), len(rest))
                        body += rest[:take]
                        rest = rest[take:]
                    else:
                        c = conn.recv(4096)
                        if not c:
                            break
                        body += c

            path_route = path
            if path_route.startswith("/status/"):
                code = int(path_route.split("/")[2])
                reason = {404: "Not Found", 204: "No Content", 304: "Not Modified",
                          500: "Internal Server Error"}.get(code, "X")
                body_resp = f"{code} {reason}".encode()
                if code in (204, 304):
                    conn.sendall(f"HTTP/1.1 {code} {reason}\r\nContent-Length: 0\r\n\r\n".encode())
                else:
                    conn.sendall(f"HTTP/1.1 {code} {reason}\r\nContent-Length: {len(body_resp)}\r\n\r\n".encode() + body_resp)
                conn.close()
                return
            if path_route == "/big":
                data = (b"RIDECONNECT-BIG-PAYLOAD-" * (BIG_SIZE // 24 + 1))[:BIG_SIZE]
                conn.sendall(f"HTTP/1.1 200 OK\r\nContent-Length: {len(data)}\r\n\r\n".encode())
                for i in range(0, len(data), 65536):
                    conn.sendall(data[i:i + 65536])
                conn.close()
                return
            if path_route == "/chunked":
                chunks = [b"chunk-one-", b"chunk-two-", b"chunk-three"]
                out = b""
                for c in chunks:
                    out += f"{len(c):x}\r\n".encode() + c + b"\r\n"
                out += b"0\r\nX-Trailer: yes\r\n\r\n"
                conn.sendall(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n" + out)
                conn.close()
                return
            if path_route == "/close":
                conn.sendall(b"HTTP/1.1 200 OK\r\n\r\nclose-delimited-body-data")
                conn.close()
                return
            if path_route == "/slow":
                time.sleep(2.5)
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\nslow")
                conn.close()
                return
            if path_route == "/none":
                conn.close()
                return
            if path_route == "/1xx":
                body_resp = b"after-100"
                conn.sendall(f"HTTP/1.1 200 OK\r\nContent-Length: {len(body_resp)}\r\n\r\n".encode() + body_resp)
                conn.close()
                return
            if path_route == "/head":
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n")
                conn.close()
                return
            # echo route
            info = (f"METHOD={method}\nPATH={path}\nHOST={headers.get('host','')}\n"
                    f"BODY={body.decode('latin1')}").encode()
            conn.sendall(f"HTTP/1.1 200 OK\r\nContent-Length: {len(info)}\r\n\r\n".encode() + info)
            conn.close()
        except Exception:
            try:
                conn.close()
            except Exception:
                pass


# ---------------------------------------------------------------- proxy

def start_proxy(env_extra=None, target_port=BACKEND_PORT, port=PROXY_PORT):
    env = dict(os.environ)
    if env_extra:
        env.update(env_extra)
    p = subprocess.Popen([PROXY, str(port), "127.0.0.1", str(target_port)],
                         env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # wait for it to listen
    for _ in range(100):
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=0.2)
            s.close()
            return p
        except OSError:
            time.sleep(0.05)
    raise RuntimeError("proxy did not start")


def stop_proxy(p):
    try:
        p.send_signal(signal.SIGTERM)
        p.wait(timeout=3)
    except Exception:
        p.kill()


# ---------------------------------------------------------------- helpers

def http_get(port, path="/", headers=None, raw=False):
    s = socket.create_connection(("127.0.0.1", port), timeout=10)
    req = f"GET {path} HTTP/1.1\r\nHost: test\r\nConnection: close\r\n"
    for k, v in (headers or {}).items():
        req += f"{k}: {v}\r\n"
    req += "\r\n"
    s.sendall(req.encode())
    data = b""
    while True:
        c = s.recv(65536)
        if not c:
            break
        data += c
    s.close()
    if raw:
        return data
    head, _, body = data.partition(b"\r\n\r\n")
    lines = head.decode("latin1").split("\r\n")
    status = int(lines[0].split(" ")[1])
    hdrs = {}
    for ln in lines[1:]:
        if ":" in ln:
            k, _, v = ln.partition(":")
            hdrs[k.strip().lower()] = v.strip()
    if hdrs.get("transfer-encoding", "").lower() == "chunked":
        decoded = b""
        while True:
            line, _, body = body.partition(b"\r\n")
            n = int(line.split(b";")[0], 16)
            if n == 0:
                break
            decoded += body[:n]
            body = body[n + 2:]
        body = decoded
    return status, hdrs, body


def raw_request(port, payload, timeout=10, read_all=True):
    s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
    s.sendall(payload)
    data = b""
    s.settimeout(timeout)
    while read_all:
        try:
            c = s.recv(65536)
        except socket.timeout:
            break
        except ConnectionResetError:
            break
        if not c:
            break
        data += c
    s.close()
    return data


def status_of(raw):
    try:
        return int(raw.split(b"\r\n", 1)[0].split(b" ")[1])
    except Exception:
        return None


# ---------------------------------------------------------------- tests

def test_basic_relay(backend):
    st, hdrs, body = http_get(PROXY_PORT, "/echo?x=1", headers={"X-Custom": "abc"})
    ok("GET relay", st == 200 and b"METHOD=GET" in body and b"PATH=/echo" in body
       and b"HOST=test" in body, body[:80])
    st, hdrs, body = http_get(PROXY_PORT, "/status/404")
    ok("404 relayed", st == 404 and body == b"404 Not Found")
    st, hdrs, body = http_get(PROXY_PORT, "/status/500")
    ok("500 relayed", st == 500)


def test_post_body(backend):
    s = socket.create_connection(("127.0.0.1", PROXY_PORT), timeout=10)
    body = b"hello-world-body"
    req = (f"POST /echo HTTP/1.1\r\nHost: t\r\nContent-Length: {len(body)}\r\n"
           f"Connection: close\r\n\r\n").encode() + body
    s.sendall(req)
    data = b""
    while True:
        c = s.recv(65536)
        if not c:
            break
        data += c
    s.close()
    ok("POST body relayed", status_of(data) == 200 and b"BODY=hello-world-body" in data)


def test_chunked_request(backend):
    s = socket.create_connection(("127.0.0.1", PROXY_PORT), timeout=10)
    payload = b"POST /echo HTTP/1.1\r\nHost: t\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n" \
              + b"5\r\nhello\r\n6\r\n world\r\n0\r\n\r\n"
    s.sendall(payload)
    data = b""
    while True:
        c = s.recv(65536)
        if not c:
            break
        data += c
    s.close()
    ok("chunked request body relayed", status_of(data) == 200 and b"BODY=hello world" in data)


def test_binary_integrity(backend):
    st, hdrs, body = http_get(PROXY_PORT, "/big")
    h = hashlib.sha256(body).hexdigest()
    expect = hashlib.sha256(
        (b"RIDECONNECT-BIG-PAYLOAD-" * (BIG_SIZE // 24 + 1))[:BIG_SIZE]).hexdigest()
    ok("5MB binary SHA-256 through proxy", st == 200 and len(body) == BIG_SIZE and h == expect,
       f"len={len(body)}")


def test_concurrency(backend):
    # 20 parallel requests from the same IP would exceed the default per-IP
    # connection cap (16), so give this test its own proxy with higher limits.
    p = start_proxy({"RC_MAX_PER_IP": "64", "RC_MAX_TOTAL": "200"}, port=18103)
    try:
        results = []
        def worker():
            try:
                st, _, body = http_get(18103, "/echo")
                results.append(st == 200 and b"METHOD=GET" in body)
            except Exception:
                results.append(False)
        threads = [threading.Thread(target=worker) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        ok("20 concurrent requests", all(results), f"{sum(results)}/20")
    finally:
        stop_proxy(p)


def test_keep_alive(backend):
    # own proxy so no other test's connections are counted against us
    p = start_proxy({}, port=18104)
    try:
        s = socket.create_connection(("127.0.0.1", 18104), timeout=10)
        req1 = b"GET /echo?n=1 HTTP/1.1\r\nHost: t\r\n\r\n"
        req2 = b"GET /echo?n=2 HTTP/1.1\r\nHost: t\r\n\r\n"
        s.sendall(req1)
        time.sleep(0.3)
        s.sendall(req2)
        s.settimeout(10)
        data = b""
        while True:
            try:
                c = s.recv(65536)
            except socket.timeout:
                break
            except ConnectionResetError:
                break
            if not c:
                break
            data += c
        s.close()
        n1 = data.count(b"PATH=/echo")
        ok("keep-alive: two requests one connection", n1 >= 2, f"responses={n1}")
        ok("keep-alive: both 200", data.count(b"HTTP/1.1 200 OK") >= 2)
    finally:
        stop_proxy(p)


def test_response_chunked(backend):
    st, hdrs, body = http_get(PROXY_PORT, "/chunked")
    ok("chunked response decoded by client",
       st == 200 and body == b"chunk-one-chunk-two-chunk-three", body[:40])


def test_response_close_delimited(backend):
    st, hdrs, body = http_get(PROXY_PORT, "/close")
    ok("close-delimited response relayed",
       st == 200 and body == b"close-delimited-body-data", body[:40])


def test_response_head_method(backend):
    s = socket.create_connection(("127.0.0.1", PROXY_PORT), timeout=10)
    s.sendall(b"HEAD /head HTTP/1.1\r\nHost: t\r\nConnection: close\r\n\r\n")
    data = b""
    while True:
        c = s.recv(65536)
        if not c:
            break
        data += c
    s.close()
    st = status_of(data)
    ok("HEAD request: no body relayed", st == 200 and data.count(b"\r\n\r\n") == 1
       and b"Content-Length: 5" in data)


def test_1xx_continue(backend):
    s = socket.create_connection(("127.0.0.1", PROXY_PORT), timeout=10)
    s.sendall(b"POST /1xx HTTP/1.1\r\nHost: t\r\nContent-Length: 4\r\n"
              b"Expect: 100-continue\r\nConnection: close\r\n\r\n")
    s.settimeout(10)
    data = b""
    # read until we get the 100 Continue relayed
    while b"100 Continue" not in data:
        c = s.recv(4096)
        if not c:
            break
        data += c
    ok("Expect: 100-continue relayed", b"100 Continue" in data)
    s.sendall(b"BODY")
    while True:
        try:
            c = s.recv(65536)
        except socket.timeout:
            break
        except ConnectionResetError:
            break
        if not c:
            break
        data += c
    s.close()
    ok("final response after 100-continue", b"HTTP/1.1 200 OK" in data
       and b"after-100" in data, data[:120])


def test_backend_down(backend):
    # point the proxy at a port with nothing listening -> connection refused -> 502
    p = start_proxy({}, target_port=19999, port=18091)
    try:
        st, _, body = http_get(18091, "/")
        ok("backend down -> 502", st == 502, f"got {st}")
    finally:
        stop_proxy(p)


def test_backend_slow(backend):
    p = start_proxy({"RC_BACKEND_TIMEOUT": "1"}, port=18092)
    try:
        st, _, body = http_get(18092, "/slow")
        ok("backend slow -> 504", st == 504, f"got {st}")
    finally:
        stop_proxy(p)


def test_backend_garbage(backend):
    p = start_proxy({"RC_BACKEND_TIMEOUT": "1"}, port=18093)
    try:
        st, _, _ = http_get(18093, "/none")
        ok("backend closes without response -> 502", st == 502, f"got {st}")
    finally:
        stop_proxy(p)


# ---------------------------------------------------------------- L7 protections

def test_malformed(backend):
    cases = [
        (b"GARBAGE\r\n\r\n", 400, "garbage request line"),
        (b"GET /x HTTP/1.1\r\nHost: t\r\nBadHeaderLine\r\n\r\n", 400, "header without colon"),
        (b"GET /x HTTP/1.1\r\nHost: t\r\n Continuation\r\n\r\n", 400, "obs-fold"),
        (b"GET /x HTTP/1.1\r\nHost: t\r\nX-Bad: \x01\x02\r\n\r\n", 400, "control char in header"),
        (b"GET /x HTTP/1.1\r\nHost: \r\n\r\n", 400, "empty Host value"),
        (b"GET /x HTTP/1.1\r\nHost: t\r\nContent-Length: 5\r\nContent-Length: 6\r\n\r\n", 400, "duplicate Content-Length"),
        (b"POST /x HTTP/1.1\r\nHost: t\r\nContent-Length: 5\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n", 400, "TE+CL smuggling"),
        (b"GET /x HTTP/1.1\r\nHost: t\r\nContent-Length: abc\r\n\r\n", 400, "non-numeric Content-Length"),
        (b"GET /x HTTP/1.1\r\nHost: t\r\nContent-Length: 5, 5\r\n\r\n", 400, "comma Content-Length"),
        (b"GET http://evil.com/x HTTP/1.1\r\nHost: t\r\n\r\n", 400, "absolute-form URI"),
        (b"GET /x\r\n\r\n", 400, "no version"),
        (b"GET /x HTTP/1.1 extra\r\nHost: t\r\n\r\n", 400, "trailing junk after version"),
    ]
    for payload, want, name in cases:
        raw = raw_request(PROXY_PORT, payload)
        ok(f"malformed: {name} -> 400", status_of(raw) == want, f"got {status_of(raw)}")


def test_method_whitelist(backend):
    for method, path in [(b"TRACE", b"/x"), (b"CONNECT", b"/x"), (b"PURGE", b"/x")]:
        raw = raw_request(PROXY_PORT, method + b" " + path + b" HTTP/1.1\r\nHost: t\r\n\r\n")
        ok(f"method rejected {method.decode()}", status_of(raw) == 405, f"got {status_of(raw)}")
    raw = raw_request(PROXY_PORT, b"get /x HTTP/1.1\r\nHost: t\r\n\r\n")
    ok("lowercase method rejected", status_of(raw) in (400, 405), f"got {status_of(raw)}")
    raw = raw_request(PROXY_PORT, b"DELETE /echo HTTP/1.1\r\nHost: t\r\n\r\n")
    ok("DELETE allowed", status_of(raw) == 200, f"got {status_of(raw)}")
    raw = raw_request(PROXY_PORT, b"OPTIONS /echo HTTP/1.1\r\nHost: t\r\n\r\n")
    ok("OPTIONS allowed", status_of(raw) == 200, f"got {status_of(raw)}")


def test_version_check(backend):
    raw = raw_request(PROXY_PORT, b"GET /x HTTP/2.0\r\nHost: t\r\n\r\n")
    ok("HTTP/2.0 -> 505", status_of(raw) == 505, f"got {status_of(raw)}")
    raw = raw_request(PROXY_PORT, b"GET /x HTTP/1.0\r\n\r\n")
    ok("HTTP/1.0 without Host allowed", status_of(raw) in (200, 502), f"got {status_of(raw)}")


def test_missing_host(backend):
    raw = raw_request(PROXY_PORT, b"GET /x HTTP/1.1\r\n\r\n")
    ok("HTTP/1.1 without Host -> 400", status_of(raw) == 400, f"got {status_of(raw)}")


def test_uri_too_long(backend):
    uri = b"/" + b"a" * 9000
    raw = raw_request(PROXY_PORT, b"GET " + uri + b" HTTP/1.1\r\nHost: t\r\n\r\n")
    ok("URI too long -> 414", status_of(raw) == 414, f"got {status_of(raw)}")


def test_header_too_large(backend):
    big = b"X-Big: " + b"a" * (20 * 1024) + b"\r\n"
    raw = raw_request(PROXY_PORT, b"GET /x HTTP/1.1\r\nHost: t\r\n" + big + b"\r\n")
    ok("oversized header -> 431", status_of(raw) == 431, f"got {status_of(raw)}")


def test_body_too_large(backend):
    p = start_proxy({"RC_MAX_BODY_MB": "1"}, port=18094)
    try:
        s = socket.create_connection(("127.0.0.1", 18094), timeout=10)
        body = b"a" * (2 * 1024 * 1024)
        try:
            s.sendall(f"POST /echo HTTP/1.1\r\nHost: t\r\nContent-Length: {len(body)}\r\n"
                      f"Connection: close\r\n\r\n".encode() + body)
        except (BrokenPipeError, ConnectionResetError):
            pass  # proxy rejects early; the 413 is already queued
        data = b""
        while True:
            try:
                c = s.recv(65536)
            except ConnectionResetError:
                break
            if not c:
                break
            data += c
        s.close()
        ok("oversized body -> 413", status_of(data) == 413, f"got {status_of(data)}")
    finally:
        stop_proxy(p)


def test_chunked_overflow(backend):
    p = start_proxy({"RC_MAX_BODY_MB": "1"}, port=18095)
    try:
        s = socket.create_connection(("127.0.0.1", 18095), timeout=10)
        big = b"a" * (2 * 1024 * 1024)
        payload = (b"POST /echo HTTP/1.1\r\nHost: t\r\nTransfer-Encoding: chunked\r\n"
                   b"Connection: close\r\n\r\n" + f"{len(big):x}\r\n".encode() + big + b"\r\n0\r\n\r\n")
        try:
            s.sendall(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass  # proxy rejects early; the 413 is already queued
        data = b""
        while True:
            try:
                c = s.recv(65536)
            except ConnectionResetError:
                break
            if not c:
                break
            data += c
        s.close()
        ok("oversized chunked body -> 413", status_of(data) == 413, f"got {status_of(data)}")
    finally:
        stop_proxy(p)


def test_slowloris(backend):
    p = start_proxy({"RC_HEADER_TIMEOUT": "1"}, port=18096)
    try:
        s = socket.create_connection(("127.0.0.1", 18096), timeout=10)
        s.sendall(b"GET /x HTTP/1.1\r\nHost: t\r\n")  # partial head, never finished
        time.sleep(0.2)
        s.sendall(b"X-Partial: ")
        s.settimeout(5)
        data = b""
        try:
            while True:
                c = s.recv(4096)
                if not c:
                    break
                data += c
        except socket.timeout:
            pass
        s.close()
        ok("slowloris partial head -> 408", status_of(data) == 408, f"got {status_of(data)}")
    finally:
        stop_proxy(p)


def test_slowloris_idle(backend):
    p = start_proxy({"RC_HEADER_TIMEOUT": "1"}, port=18097)
    try:
        s = socket.create_connection(("127.0.0.1", 18097), timeout=10)
        s.settimeout(5)
        data = b""
        try:
            while True:
                c = s.recv(4096)
                if not c:
                    break
                data += c
        except socket.timeout:
            pass
        s.close()
        ok("idle connection closed without response", data == b"")
    finally:
        stop_proxy(p)


def test_rate_limit(backend):
    p = start_proxy({"RC_RATE": "5", "RC_BURST": "5"}, port=18098)
    try:
        codes = []
        for _ in range(12):
            st, _, body = http_get(18098, "/echo")
            codes.append(st)
        ok("burst of 5 allowed, rest 429", codes.count(200) >= 4 and 429 in codes,
           f"codes={codes}")
        # after waiting 1s, the bucket refills (rate 5/s) -> request allowed again
        time.sleep(1.2)
        st, _, _ = http_get(18098, "/echo")
        ok("rate limit refills after delay", st == 200, f"got {st}")
        # 429 responses carry Retry-After (fresh connection per attempt)
        d = b""
        for _ in range(10):
            s = socket.create_connection(("127.0.0.1", 18098), timeout=10)
            s.sendall(b"GET /echo HTTP/1.1\r\nHost: t\r\nConnection: close\r\n\r\n")
            d = b""
            while True:
                c = s.recv(4096)
                if not c:
                    break
                d += c
            s.close()
            if b" 429 " in d:
                break
        ok("429 includes Retry-After header", b"Retry-After:" in d, d[:120])
    finally:
        stop_proxy(p)


def test_conn_limit_per_ip(backend):
    p = start_proxy({"RC_MAX_PER_IP": "2"}, port=18099)
    try:
        sockets = []
        for _ in range(3):
            s = socket.create_connection(("127.0.0.1", 18099), timeout=10)
            s.sendall(b"GET /slow HTTP/1.1\r\nHost: t\r\n\r\n")
            sockets.append(s)
            time.sleep(0.15)
        # third connection (well, first after two held) should be rejected
        time.sleep(0.3)
        st, _, body = http_get(18099, "/")
        ok("per-IP connection cap -> 503", st == 503, f"got {st}")
        for s in sockets:
            s.close()
        time.sleep(2.8)
        st, _, body = http_get(18099, "/")
        ok("connections freed after backend done", st == 200, f"got {st}")
    finally:
        stop_proxy(p)


def test_idle_keepalive_timeout(backend):
    p = start_proxy({"RC_IDLE_TIMEOUT": "1"}, port=18100)
    try:
        s = socket.create_connection(("127.0.0.1", 18100), timeout=10)
        s.sendall(b"GET /echo HTTP/1.1\r\nHost: t\r\n\r\n")
        time.sleep(0.3)
        s.settimeout(4)
        first = b""
        while True:
            try:
                c = s.recv(4096)
            except socket.timeout:
                break
            if not c:
                break
            first += c
        ok("keep-alive first response ok", b"200 OK" in first)
        # wait past idle timeout -> proxy closes the connection
        time.sleep(1.5)
        s.settimeout(2)
        try:
            c = s.recv(4096)
            closed = (c == b"")
        except socket.timeout:
            closed = False
        s.close()
        ok("keep-alive idle timeout closes connection", closed)
    finally:
        stop_proxy(p)


def test_keepalive_max_requests(backend):
    p = start_proxy({"RC_MAX_REQS": "3"}, port=18101)
    try:
        s = socket.create_connection(("127.0.0.1", 18101), timeout=10)
        s.settimeout(8)
        data = b""
        for i in range(5):
            try:
                s.sendall(f"GET /echo?i={i} HTTP/1.1\r\nHost: t\r\n\r\n".encode())
            except (BrokenPipeError, ConnectionResetError):
                break  # proxy closed the connection after the cap
            time.sleep(0.2)
        while True:
            try:
                c = s.recv(65536)
            except socket.timeout:
                break
            if not c:
                break
            data += c
        s.close()
        n_ok = data.count(b"200 OK")
        ok("connection capped at 3 requests", 3 <= n_ok < 5, f"got {n_ok}")
    finally:
        stop_proxy(p)


def test_ipv6ish_host_target(backend):
    # hostname resolution should work too
    p = start_proxy({}, port=18102)
    try:
        st, _, body = http_get(18102, "/echo")
        ok("target resolution via hostname (localhost)", st == 200, f"got {st}")
    finally:
        stop_proxy(p)


# ---------------------------------------------------------------- main

def main():
    backend = Backend(BACKEND_PORT)
    backend.start()
    proxy = start_proxy({})
    time.sleep(0.3)
    try:
        print("== relay correctness ==")
        test_basic_relay(backend)
        test_post_body(backend)
        test_chunked_request(backend)
        test_binary_integrity(backend)
        test_concurrency(backend)
        test_keep_alive(backend)
        test_response_chunked(backend)
        test_response_close_delimited(backend)
        test_response_head_method(backend)
        test_1xx_continue(backend)
        test_ipv6ish_host_target(backend)
        print("== backend failure handling ==")
        test_backend_down(backend)
        test_backend_slow(backend)
        test_backend_garbage(backend)
        print("== layer-7 protections ==")
        test_malformed(backend)
        test_method_whitelist(backend)
        test_version_check(backend)
        test_missing_host(backend)
        test_uri_too_long(backend)
        test_header_too_large(backend)
        test_body_too_large(backend)
        test_chunked_overflow(backend)
        test_slowloris(backend)
        test_slowloris_idle(backend)
        test_rate_limit(backend)
        test_conn_limit_per_ip(backend)
        test_idle_keepalive_timeout(backend)
        test_keepalive_max_requests(backend)
    finally:
        stop_proxy(proxy)
        backend.close()
    print()
    print(f"TOTAL: {PASS} passed, {FAIL} failed")
    if FAILURES:
        print("FAILED:")
        for f in FAILURES:
            print("  -", f)
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
