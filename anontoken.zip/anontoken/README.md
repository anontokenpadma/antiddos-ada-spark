# anontoken — rideconnect DDoS-protection proxy (full environment backup)

Gói toàn bộ môi trường làm việc tại thời điểm **2026-08-19** sau khi đạt
**SPARK proved 100% (465/465)** và deploy lên Raspberry Pi.

---

## 1. Tổng quan dự án

`rideconnect` = reverse proxy chống DDoS tầng 7 viết bằng Ada 2022 / SPARK,
tự chứa TLS 1.3 (RFC 8446), chạy trên Raspberry Pi đứng sau Cloudflare tunnel.

### Các lớp phòng thủ (đã deploy trên Pi)
| Lớp | Cơ chế |
|---|---|
| Cloudflare edge | Bot protection |
| iptables connlimit 400 | kernel reject >400 conn đồng thời (đã save `/etc/iptables/rules.v4`) |
| Proxy backlog 4096 | accept drain nhanh |
| max_total=384 | giới hạn conn tổng (dưới FD ulimit 1024) |
| per-IP 16 conn | giới hạn conn/IP |
| global RPS 300/s | token bucket toàn proxy → 429 |
| per-IP 20/s burst 40 | token bucket/IP → 429 |
| parser nghiêm ngặt | 400 cho smuggling/injection/double-Host/chunk malformed |

### Kết quả 6+ vòng tấn công thực tế
- Vòng 1-4: phát hiện & fix per-IP thật, global RPS, connlimit, backlog
- Vòng 5-6: site sống xuyên suốt, cloudflared RSS ổn định ~380-400MB
  (trước đó 2.2GB → OOM)

---

## 2. 4 file chính (bản mới nhất)

| File | md5 |
|---|---|
| `project/src/rideconnect.adb` | `2e1cb50f7874b79cc852afc36869708d` |
| `project/bin/rideconnect` (Linux x86_64) | `f3a4e350047a03b642c3cff611dd2c28` |
| `project/bin/rideconnect.exe` (Windows) | `32647cfdc6d7234701c0fd725b95d689` |
| `project/bin/rideconnect_arm64` (Linux ARM64) | `5d07ffe41d7e1cb77b99c77ea9589fa8` |

⚠️ **ARM64 phải build với `build_arm64.sh`** (không phải gnatmake trần):
- Toolchain `/home/jovyan/.local/aarch64` bị di dời → libc.so/libm.so là linker
  script Debian với đường dẫn cứng → cần bản sửa trong `/tmp/mylib`
- Pragma `Linker_Options ("--unresolved-symbols=ignore-all")` (RtlGenRandom
  Windows) tạo R_AARCH64_NONE PLT hole → glibc cũ trên Pi báo
  `unexpected PLT reloc type 0x00` → fix bằng `-Wl,--defsym=SystemFunction036=0`

---

## 3. SPARK proof (465/465 = 100%)

- Harness: `project/src/spark_core.{ads,adb}` + `project/src/spark.gpr`
- Regenerate từ source: `python3 project/src/extract_spark.py both`
- Chạy proof: `gnatprove -P project/src/spark.gpr --level=4 -j21 --prover=cvc5,z3,altergo --timeout=30 --report=all`
- Kết quả: `proof/gnatprove_summary.txt`
  - Run-time Checks 302/302, Assertions 70/70, Functional Contracts 20/20,
    Termination 15/15 → **465/465, 0 unproved**
- **Key fix đạt 100%:** thêm postcondition cho `Find_Byte`:
  ```ada
  with Post => (Find_Byte'Result = 0)
    or else (Find_Byte'Result in S .. L and then Buf (Find_Byte'Result) = C);
  ```
  (chữa cả 19 check unproved còn lại trong Parse_Response/Scan_Headers/Parse_Request_Line)

---

## 4. Kết nối Pi (gsocket)

- Tool: `tools/gs-netcat` (binary client x86_64)
- Pi chạy: `./gs-netcat_linux-aarch64 -s anontokenss -l -q -i -e bash` (trong tmux)
- Gửi lệnh tới Pi:
  ```bash
  cat /tmp/pi_xxx.sh | timeout 60 /tmp/gs-netcat -s anontokenss -q
  ```
- Chuyển file tới Pi (2 bước, token riêng):
  1. Trên Pi: `nohup gs-netcat_linux-aarch64 -l -s <token> -q > file.new 2>/dev/null &`
  2. Local: `cat file | /tmp/gs-netcat -s <token> -q`
- Tất cả script Pi dùng được: `pi_scripts/` (poll, swap, verify, firewall...)

### Trạng thái Pi lúc đóng gói
- Proxy mới nhất PID 254991: `./rideconnect_arm64 9999 127.0.0.1 80`
  (log: `rate=20/s burst=40 global=300/s max_per_ip=16 max_total=384`)
- Backlog `LISTEN 0 4096`, connlimit active line 1 INPUT
- Tunnel: `https://anontokenforever.dpdns.org` → HTTP 200
- Pi directory: `/home/anontoken/anontoken/` (binaries + gs-netcat + tmux pane 1:0.0)

---

## 5. Build & test local

```bash
# Native
cd project && alr build            # → bin/rideconnect
RC_SELF_TEST=1 ./bin/rideconnect   # selftest crypto: ALL PASS

# Windows (mingw, toolchain /home/jovyan/.local/mingw)
x86_64-w64-mingw32ucrt-gnatmake -O2 -gnatVa -gnat2022 -o rideconnect.exe rideconnect.adb

# ARM64 (bắt buộc dùng script)
bash project/build_arm64.sh        # → bin/rideconnect_arm64

# Tests
alr exec -- python3 test_proxy.py  # 53 passed
alr exec -- python3 attack_test.py # 52 blocked, 2 leaked (hợp lệ)
```

---

## 6. Cảnh báo / việc còn lại
- `netfilter-persistent` chưa cài — iptables rules sẽ mất nếu Pi reboot
  (đã save `/etc/iptables/rules.v4`, cần systemd service để tự load)
- `rideconnect.exe` build xong nhưng chưa test hành vi (môi trường không chạy Windows)
- GNATprove full log: `proof/spark_full_proof.log`
- Toolchain path: `/home/jovyan/.local/aarch64` (GCC 16 + binutils 2.47.50),
  `/home/jovyan/.local/mingw` (Windows), `/home/jovyan/.local/aarch64-13` (dự phòng GCC 13)
