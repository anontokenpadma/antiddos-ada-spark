import socket, subprocess, time, os, signal, threading

def backend(port):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", port)); s.listen(128)
    def serve():
        while True:
            try: c,_ = s.accept()
            except Exception: return
            try:
                c.recv(65536)
                c.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: keep-alive\r\n\r\nOK")
            except Exception: pass
    threading.Thread(target=serve, daemon=True).start()
    return s

def req(port, raw):
    s = socket.create_connection(("127.0.0.1", port), timeout=3)
    s.sendall(raw)
    s.settimeout(3)
    try:
        resp = s.recv(4096)
        code = resp.split(b"\r\n")[0].decode(errors="replace").split()[1]
    except Exception:
        code = "ERR"
    s.close()
    return code

# ---- Test A: double-Host -> 400 ----
BK, PR = 19001, 19002
bk = backend(BK)
p = subprocess.Popen(["./bin/rideconnect", str(PR), "127.0.0.1", str(BK)],
                     env=dict(os.environ, RC_MAX_PER_IP="100", RC_MAX_TOTAL="500",
                              RC_RATE="10000", RC_BURST="100000", RC_GLOBAL_RPS="100000"),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
r1 = req(PR, b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
r2 = req(PR, b"GET / HTTP/1.1\r\nHost: a\r\nHost: b\r\n\r\n")
print(f"A1 single Host: {r1} -> {'PASS ✅' if r1=='200' else 'FAIL ❌'}")
print(f"A2 double Host: {r2} -> {'PASS ✅' if r2=='400' else 'FAIL ❌'}")
os.kill(p.pid, signal.SIGTERM); p.wait(timeout=5); bk.close(); time.sleep(0.5)

# ---- Test B: global RPS gate ----
BK2, PR2 = 19011, 19012
bk2 = backend(BK2)
p2 = subprocess.Popen(["./bin/rideconnect", str(PR2), "127.0.0.1", str(BK2)],
                      env=dict(os.environ, RC_MAX_PER_IP="1000", RC_MAX_TOTAL="2000",
                               RC_RATE="10000", RC_BURST="100000", RC_GLOBAL_RPS="5"),
                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
codes = [req(PR2, f"GET / HTTP/1.1\r\nHost: x\r\nCF-Connecting-IP: 10.0.{i//250}.{i%250}\r\n\r\n".encode()) for i in range(25)]
n200, n429 = codes.count("200"), codes.count("429")
print(f"B1 global gate (25 IP khác, rate=5/s burst=20): 200={n200} 429={n429} -> {'PASS ✅' if n200<=21 and n429>=4 else 'FAIL ❌'}")
os.kill(p2.pid, signal.SIGTERM); p2.wait(timeout=5); bk2.close(); time.sleep(0.5)

# ---- Test C: per-IP still works ----
BK3, PR3 = 19021, 19022
bk3 = backend(BK3)
p3 = subprocess.Popen(["./bin/rideconnect", str(PR3), "127.0.0.1", str(BK3)],
                      env=dict(os.environ, RC_MAX_PER_IP="1000", RC_MAX_TOTAL="2000",
                               RC_RATE="1", RC_BURST="2", RC_GLOBAL_RPS="100000"),
                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
c = [req(PR3, f"GET / HTTP/1.1\r\nHost: x\r\nCF-Connecting-IP: 5.5.5.5\r\n\r\n".encode()) for _ in range(3)]
print(f"C1 per-IP cùng IP x3: {c} -> {'PASS ✅' if c==['200','200','429'] else 'FAIL ❌'}")
os.kill(p3.pid, signal.SIGTERM); p3.wait(timeout=5); bk3.close()
print("=== DONE ===")
